const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3001;
const DATA_FILE = path.join(__dirname, 'data', 'inventory.json');
const USERS_FILE = path.join(__dirname, 'data', 'users.json');
const SETTINGS_FILE = path.join(__dirname, 'data', 'settings.json');
const SESSIONS = {};

app.use(express.json({ limit: '20mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Ensure data directory exists
if (!fs.existsSync(path.join(__dirname, 'data'))) {
  fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
}

function hashPass(p) { return crypto.createHash('sha256').update(p).digest('hex'); }

// ── DEFAULT DATA ──
const defaultUsers = {
  users: [{ id: 1, username: 'admin', password: hashPass('Admin@1234'), role: 'admin', name: 'Administrator', company: '' }],
  nextId: 2
};
function readUsers() { try { if (fs.existsSync(USERS_FILE)) return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8')); } catch(e) {} return { ...defaultUsers }; }
function writeUsers(d) { fs.writeFileSync(USERS_FILE, JSON.stringify(d, null, 2)); }
if (!fs.existsSync(USERS_FILE)) writeUsers({ ...defaultUsers });

const defaultSettings = {
  appName: 'IT Asset Inventory',
  companyName: 'My Company',
  address: 'Office Address',
  phone: '',
  email: '',
  mainLogo: '',
  loginBackground: '',
  companyLogos: {},
  slackWebhook: '',
  slackBotName: 'IT Asset Bot',
  slackChannel: '#it-assets'
};
function readSettings() { try { if (fs.existsSync(SETTINGS_FILE)) return JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')); } catch(e) {} return { ...defaultSettings }; }
function writeSettings(d) { fs.writeFileSync(SETTINGS_FILE, JSON.stringify(d, null, 2)); }
if (!fs.existsSync(SETTINGS_FILE)) writeSettings({ ...defaultSettings });

const defaultData = { companies: ['MyCompany'], assets: [], nextId: 1, employees: [], nextEmpId: 1 };
function readData() { try { if (fs.existsSync(DATA_FILE)) return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch(e) {} return { ...defaultData }; }
function writeData(d) { fs.writeFileSync(DATA_FILE, JSON.stringify(d, null, 2)); }
if (!fs.existsSync(DATA_FILE)) writeData({ ...defaultData });

// ── AUTH MIDDLEWARE ──
function auth(req, res, next) {
  const token = req.headers['x-session'];
  if (!token || !SESSIONS[token]) return res.status(401).json({ error: 'Unauthorized' });
  req.user = SESSIONS[token];
  next();
}
function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
  next();
}

// ── PUBLIC BRANDING (no auth needed for login page) ──
app.get('/api/branding', (req, res) => {
  const s = readSettings();
  res.json({ appName: s.appName, companyName: s.companyName, address: s.address, mainLogo: s.mainLogo || '', loginBackground: s.loginBackground || '' });
});

// ── AUTH ROUTES ──
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const ud = readUsers();
  const user = ud.users.find(u => u.username === username && u.password === hashPass(password));
  if (!user) return res.status(401).json({ error: 'Invalid username or password' });
  const token = crypto.randomBytes(32).toString('hex');
  SESSIONS[token] = { id: user.id, username: user.username, role: user.role, name: user.name, company: user.company || '' };
  res.json({ token, role: user.role, name: user.name, username: user.username, company: user.company || '' });
});
app.post('/api/logout', (req, res) => { const token = req.headers['x-session']; if (token) delete SESSIONS[token]; res.json({ success: true }); });
app.get('/api/me', auth, (req, res) => res.json(req.user));

// ── USER ROUTES ──
app.get('/api/users', auth, adminOnly, (req, res) => {
  const ud = readUsers();
  res.json(ud.users.map(u => ({ id: u.id, username: u.username, role: u.role, name: u.name, company: u.company || '' })));
});
app.post('/api/users', auth, adminOnly, (req, res) => {
  const { username, password, role, name, company } = req.body;
  if (!username || !password || !role || !name) return res.status(400).json({ error: 'All fields required' });
  const ud = readUsers();
  if (ud.users.find(u => u.username === username)) return res.status(400).json({ error: 'Username already exists' });
  ud.users.push({ id: ud.nextId++, username, password: hashPass(password), role, name, company: company || '' });
  writeUsers(ud); res.json({ success: true });
});
app.put('/api/users/:id', auth, adminOnly, (req, res) => {
  const id = parseInt(req.params.id);
  const { username, password, role, name, company } = req.body;
  const ud = readUsers();
  const idx = ud.users.findIndex(u => u.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  ud.users[idx] = { ...ud.users[idx], ...(username && { username }), ...(role && { role }), ...(name && { name }), company: company !== undefined ? company : ud.users[idx].company || '' };
  if (password) ud.users[idx].password = hashPass(password);
  writeUsers(ud); res.json({ success: true });
});
app.delete('/api/users/:id', auth, adminOnly, (req, res) => {
  const id = parseInt(req.params.id);
  if (id === req.user.id) return res.status(400).json({ error: 'Cannot delete yourself' });
  const ud = readUsers();
  ud.users = ud.users.filter(u => u.id !== id);
  writeUsers(ud); res.json({ success: true });
});

// ── DATA ROUTES ──
app.get('/api/data', auth, (req, res) => res.json(readData()));
app.post('/api/data', auth, (req, res) => {
  try { writeData(req.body); res.json({ success: true }); }
  catch(e) { res.status(500).json({ error: 'Failed to save' }); }
});
app.delete('/api/company/:name', auth, adminOnly, (req, res) => {
  const name = decodeURIComponent(req.params.name);
  const d = readData();
  d.assets = d.assets.filter(a => a.company !== name);
  d.companies = d.companies.filter(c => c !== name);
  writeData(d); res.json({ success: true });
});

// ── SETTINGS ROUTES ──
app.get('/api/settings', auth, (req, res) => res.json(readSettings()));
app.post('/api/settings', auth, adminOnly, (req, res) => {
  try { writeSettings(req.body); res.json({ success: true }); }
  catch(e) { res.status(500).json({ error: 'Failed to save settings' }); }
});

// ── SLACK PROXY ──
app.post('/api/slack', auth, async (req, res) => {
  const { webhook, payload } = req.body;
  if (!webhook) return res.status(400).json({ error: 'No webhook URL' });
  try {
    const https = require('https');
    const data = JSON.stringify(payload);
    const url = new URL(webhook);
    const options = { hostname: url.hostname, path: url.pathname + url.search, method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } };
    await new Promise((resolve, reject) => {
      const r = https.request(options, resp => { resp.on('data', () => {}); resp.on('end', resolve); });
      r.on('error', reject); r.write(data); r.end();
    });
    res.json({ success: true });
  } catch(e) { res.status(500).json({ error: 'Slack request failed' }); }
});

app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n✅ IT Asset Inventory running!`);
  console.log(`   Local:  http://localhost:${PORT}`);
  console.log(`   Network: http://YOUR_SERVER_IP:${PORT}`);
  console.log(`   Login:  admin / Admin@1234\n`);
});
