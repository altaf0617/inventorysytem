# IT Asset Inventory System
## Complete Deployment Guide

---

## What is this?
A full IT Asset Inventory web application built with:
- **Backend:** Node.js + Express.js
- **Frontend:** HTML + CSS + Vanilla JavaScript (no frameworks)
- **Database:** JSON flat files (no MySQL/MongoDB needed)
- **Process Manager:** PM2 (auto-restart, survives reboots)

---

## Files Required
```
index.html    → Frontend (place in public/ folder)
server.js     → Backend API
package.json  → Node dependencies (auto-created by install)
```

---

## STEP-BY-STEP INSTALLATION

### Step 1 — Upload files to your Ubuntu VM
Using Termius SFTP or any SFTP client, upload:
- `index.html`
- `server.js`
to your home folder `/home/YOUR_USERNAME/`

---

### Step 2 — SSH into your server and run these commands:

```bash
# Create folder structure
mkdir -p ~/it-inventory/public
mkdir -p ~/it-inventory/data

# Move files into place
cp ~/server.js ~/it-inventory/server.js
cp ~/index.html ~/it-inventory/public/index.html

# Create package.json
cat > ~/it-inventory/package.json << 'EOF'
{
  "name": "it-inventory",
  "version": "1.0.0",
  "description": "IT Asset Inventory System",
  "main": "server.js",
  "scripts": { "start": "node server.js" },
  "dependencies": { "express": "^4.18.2" }
}
EOF
```

---

### Step 3 — Install Node.js (if not installed)
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v    # Should show v20.x.x
```

---

### Step 4 — Install dependencies
```bash
cd ~/it-inventory
npm install
```

---

### Step 5 — Install PM2 (process manager)
```bash
sudo npm install -g pm2
```

---

### Step 6 — Start the application
```bash
cd ~/it-inventory
pm2 start server.js --name "it-inventory"
pm2 save
```

---

### Step 7 — Auto-start on server reboot
```bash
pm2 startup
# Copy and run the command it gives you, then:
pm2 save
```

---

### Step 8 — Open firewall port
```bash
sudo ufw allow 3001
sudo ufw status
```

---

### Step 9 — Access the application
Open any browser on your network:
```
http://YOUR_SERVER_IP:3001
```

Default login:
```
Username: admin
Password: Admin@1234
```
**⚠️ Change the password immediately from Settings after first login!**

---

## USEFUL COMMANDS

```bash
# Check if running
pm2 status

# View logs
pm2 logs it-inventory

# Restart app
pm2 restart it-inventory

# Stop app
pm2 stop it-inventory

# Delete from PM2
pm2 delete it-inventory
```

---

## CHANGE PORT (if 3001 is taken)
Edit `server.js` line:
```javascript
const PORT = process.env.PORT || 3001;
```
Change `3001` to any free port e.g. `3005`, then restart:
```bash
pm2 restart it-inventory
sudo ufw allow YOUR_NEW_PORT
```

---

## BACKUP YOUR DATA
All data is stored in JSON files — super easy to backup:
```bash
# Backup
cp -r ~/it-inventory/data ~/it-inventory-backup-$(date +%Y%m%d)

# Restore
cp -r ~/it-inventory-backup-20240620/* ~/it-inventory/data/
pm2 restart it-inventory
```

---

## SETUP AFTER FIRST LOGIN

1. Go to **Settings** (gear icon or sidebar)
2. Update **App Name, Company Name, Address**
3. Upload your **Company Logo**
4. Upload **Login Background** photo
5. Add your **Companies** from the sidebar
6. Create **Junior user** accounts from User Management
7. Start adding assets!

---

## SLACK NOTIFICATIONS SETUP (Optional)

1. Go to **api.slack.com/apps** → Create New App
2. Enable **Incoming Webhooks**
3. Add webhook to your IT channel
4. Copy the webhook URL
5. Paste in **Settings → Slack Notifications**
6. Click **Send Test Message** to verify

---

## SYSTEM REQUIREMENTS
- Ubuntu 20.04 / 22.04 / 24.04
- Node.js v18+ (v20 recommended)
- 512MB RAM minimum
- 1GB free disk space
- Port 3001 (or any free port)

---

## DATABASE STRUCTURE
```
~/it-inventory/data/
├── inventory.json   ← All assets + employees + companies
├── users.json       ← Login accounts (passwords SHA-256 hashed)
└── settings.json    ← Logo, address, Slack config etc.
```

---

## TROUBLESHOOTING

**Can't access from other PCs?**
```bash
sudo ufw allow 3001
sudo ufw enable
```

**App crashed?**
```bash
pm2 logs it-inventory --lines 50
pm2 restart it-inventory
```

**Forgot admin password?**
```bash
# Delete users file to reset to defaults
rm ~/it-inventory/data/users.json
pm2 restart it-inventory
# Login: admin / Admin@1234
```

**Port already in use?**
```bash
sudo lsof -i :3001
# Change port in server.js and restart
```

---

Built with ❤️ — IT Asset Inventory System v2.0
