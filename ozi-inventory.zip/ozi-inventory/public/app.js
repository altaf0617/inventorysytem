let currentPage = 1;
let currentCategory = 'All';
let editingId = null;
let searchTimer = null;

// --- View switching ---
function showView(view, category) {
  document.querySelectorAll('[id^="view-"]').forEach(el => el.style.display = 'none');
  document.getElementById('view-' + view).style.display = '';
  document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
  if (view === 'dashboard') {
    document.querySelector('.nav-item').classList.add('active');
    loadDashboard();
  } else {
    currentCategory = category || 'All';
    currentPage = 1;
    document.getElementById('cat-filter').value = currentCategory;
    document.getElementById('assets-title').textContent =
      category === 'Desktop' ? 'Desktops' : category === 'Laptop' ? 'Laptops' : 'All Assets';
    loadAssets();
  }
}

function debounceLoad() {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(loadAssets, 300);
}

// --- Dashboard ---
async function loadDashboard() {
  const stats = await fetch('/api/stats').then(r => r.json());
  const sgEl = document.getElementById('stats-grid');
  const catMap = Object.fromEntries(stats.byCategory.map(x => [x.category, x.c]));
  const condMap = Object.fromEntries(stats.byCondition.map(x => [x.machine_condition, x.c]));

  sgEl.innerHTML = `
    <div class="stat-card"><div class="stat-label">Total assets</div><div class="stat-val">${stats.total}</div></div>
    <div class="stat-card"><div class="stat-label">Desktops</div><div class="stat-val">${catMap['Desktop']||0}</div></div>
    <div class="stat-card"><div class="stat-label">Laptops</div><div class="stat-val">${catMap['Laptop']||0}</div></div>
    <div class="stat-card"><div class="stat-label">Market value</div><div class="stat-val" style="font-size:18px">PKR ${(stats.marketValue||0).toLocaleString()}</div><div class="stat-sub">current total</div></div>
    <div class="stat-card"><div class="stat-label">Purchase cost</div><div class="stat-val" style="font-size:18px">PKR ${(stats.purchaseCost||0).toLocaleString()}</div><div class="stat-sub">recorded</div></div>
    <div class="stat-card"><div class="stat-label">Needs attention</div><div class="stat-val" style="color:#A32D2D">${condMap['Poor']||0}</div><div class="stat-sub">poor condition</div></div>
  `;

  const bg = document.getElementById('breakdown-grid');
  const conds = ['Excellent','Good','Poor'];
  const condColors = { Excellent:'#0F6E56', Good:'#3B6D11', Poor:'#A32D2D' };
  bg.innerHTML = `
    <div class="breakdown-card">
      <h3>By category</h3>
      ${stats.byCategory.map(x=>`
        <div class="bar-item">
          <div class="bar-row"><span>${x.category}</span><span>${x.c}</span></div>
          <div class="bar-bg"><div class="bar-fill" style="width:${Math.round(x.c/stats.total*100)}%"></div></div>
        </div>`).join('')}
    </div>
    <div class="breakdown-card">
      <h3>By condition</h3>
      ${conds.map(c=>{const n=condMap[c]||0;return`
        <div class="bar-item">
          <div class="bar-row"><span style="color:${condColors[c]||'inherit'}">${c}</span><span>${n}</span></div>
          <div class="bar-bg"><div class="bar-fill" style="width:${stats.total?Math.round(n/stats.total*100):0}%;background:${condColors[c]||'var(--accent)'}"></div></div>
        </div>`}).join('')}
    </div>
    <div class="breakdown-card">
      <h3>By manufacturer</h3>
      ${await getMfrBreakdown(stats.total)}
    </div>
  `;

  document.getElementById('last-updated').textContent = 'Updated ' + new Date().toLocaleTimeString();

  // Recent assets
  const recent = await fetch('/api/assets?limit=5&page=1').then(r=>r.json());
  document.getElementById('recent-table').innerHTML = buildTable(recent.assets, true);
}

async function getMfrBreakdown(total) {
  const res = await fetch('/api/assets?limit=100').then(r=>r.json());
  const mfr = {};
  res.assets.forEach(a=>{ mfr[a.manufacturer]=(mfr[a.manufacturer]||0)+1; });
  return Object.entries(mfr).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([name,n])=>`
    <div class="bar-item">
      <div class="bar-row"><span>${name}</span><span>${n}</span></div>
      <div class="bar-bg"><div class="bar-fill" style="width:${Math.round(n/total*100)}%"></div></div>
    </div>`).join('');
}

// --- Assets list ---
async function loadAssets() {
  const q = document.getElementById('search')?.value || '';
  const cat = document.getElementById('cat-filter')?.value || 'All';
  const cond = document.getElementById('cond-filter')?.value || 'All';
  const params = new URLSearchParams({ q, category: cat, condition: cond, page: currentPage, limit: 15 });
  const data = await fetch('/api/assets?' + params).then(r => r.json());

  document.getElementById('asset-tbody').innerHTML = data.assets.map(a => `
    <tr onclick="openDetail(${a.id})">
      <td style="font-weight:600;color:#185FA5">${a.asset_tag}</td>
      <td><span class="badge badge-${(a.category||'').toLowerCase()}">${a.category}</span></td>
      <td>${a.model||'—'}</td>
      <td>${a.manufacturer||'—'}</td>
      <td>${a.assign_to||'—'}</td>
      <td>${a.ram||'—'}</td>
      <td style="max-width:140px">${a.gpu||'—'}</td>
      <td><span class="cond-${(a.machine_condition||'good').toLowerCase()}">${a.machine_condition||'—'}</span></td>
      <td>${a.market_value ? 'PKR '+Number(a.market_value).toLocaleString() : '—'}</td>
      <td onclick="event.stopPropagation()">
        <button class="btn btn-sm" onclick="openEdit(${a.id})">Edit</button>
        <button class="btn btn-sm btn-danger" onclick="deleteAsset(${a.id},'${a.asset_tag}')">Del</button>
      </td>
    </tr>`).join('') || '<tr><td colspan="10" style="text-align:center;padding:2rem;color:#888">No assets found.</td></tr>';

  const total = data.total;
  const totalPages = Math.ceil(total / 15) || 1;
  document.getElementById('pagination').innerHTML = `
    <span class="muted">Showing ${Math.min((currentPage-1)*15+1, total)}–${Math.min(currentPage*15, total)} of ${total} assets</span>
    <div class="pag-btns">
      <button class="btn btn-sm" onclick="changePage(-1)" ${currentPage<=1?'disabled':''}>← Prev</button>
      <button class="btn btn-sm" onclick="changePage(1)" ${currentPage>=totalPages?'disabled':''}>Next →</button>
    </div>`;
}

function buildTable(assets, mini) {
  return `<div class="table-wrap"><table>
    <thead><tr><th>Asset Tag</th><th>Model</th><th>Category</th><th>Assigned To</th><th>Condition</th><th>Market Value</th></tr></thead>
    <tbody>${assets.map(a=>`
      <tr onclick="showView('assets');setTimeout(()=>openDetail(${a.id}),100)">
        <td style="font-weight:600;color:#185FA5">${a.asset_tag}</td>
        <td>${a.model||'—'}</td>
        <td><span class="badge badge-${(a.category||'').toLowerCase()}">${a.category}</span></td>
        <td>${a.assign_to||'—'}</td>
        <td><span class="cond-${(a.machine_condition||'good').toLowerCase()}">${a.machine_condition}</span></td>
        <td>${a.market_value?'PKR '+Number(a.market_value).toLocaleString():'—'}</td>
      </tr>`).join('')}
    </tbody></table></div>`;
}

function changePage(dir) {
  currentPage += dir;
  loadAssets();
}

// --- Detail modal ---
async function openDetail(id) {
  const a = await fetch('/api/assets/'+id).then(r=>r.json());
  document.getElementById('modal-title').textContent = a.asset_tag + ' — ' + (a.model||'');
  document.getElementById('modal-body').innerHTML = `
    <div class="detail-section">
      <h3>Identity</h3>
      <div class="detail-grid">
        <div class="detail-item"><div class="detail-label">Asset tag</div><div class="detail-val">${a.asset_tag}</div></div>
        <div class="detail-item"><div class="detail-label">Serial</div><div class="detail-val">${a.serial||'—'}</div></div>
        <div class="detail-item"><div class="detail-label">Category</div><div class="detail-val">${a.category}</div></div>
        <div class="detail-item"><div class="detail-label">Manufacturer</div><div class="detail-val">${a.manufacturer||'—'}</div></div>
        <div class="detail-item"><div class="detail-label">Model</div><div class="detail-val">${a.model||'—'}</div></div>
        <div class="detail-item"><div class="detail-label">Status</div><div class="detail-val">${a.status||'—'}</div></div>
      </div>
    </div>
    <div class="detail-section">
      <h3>Assignment</h3>
      <div class="detail-grid">
        <div class="detail-item"><div class="detail-label">Assigned to</div><div class="detail-val">${a.assign_to||'—'}</div></div>
        <div class="detail-item"><div class="detail-label">Previously assigned</div><div class="detail-val">${a.prev_assigned||'—'}</div></div>
        <div class="detail-item"><div class="detail-label">Location</div><div class="detail-val">${a.location||'—'}</div></div>
        <div class="detail-item"><div class="detail-label">Supplier</div><div class="detail-val">${a.supplier||'—'}</div></div>
        <div class="detail-item"><div class="detail-label">Purchase date</div><div class="detail-val">${a.purchase_date||'—'}</div></div>
        <div class="detail-item"><div class="detail-label">Purchase cost</div><div class="detail-val">${a.purchase_cost?'PKR '+Number(a.purchase_cost).toLocaleString():'—'}</div></div>
      </div>
    </div>
    <div class="detail-section">
      <h3>Specifications</h3>
      <div class="detail-grid">
        <div class="detail-item"><div class="detail-label">RAM</div><div class="detail-val">${a.ram||'—'}</div></div>
        <div class="detail-item"><div class="detail-label">SSD</div><div class="detail-val">${a.ssd||'—'}</div></div>
        <div class="detail-item"><div class="detail-label">HDD</div><div class="detail-val">${a.hdd||'—'}</div></div>
        <div class="detail-item"><div class="detail-label">GPU</div><div class="detail-val">${a.gpu||'—'}</div></div>
        <div class="detail-item" style="grid-column:1/-1"><div class="detail-label">Processor</div><div class="detail-val">${a.processor||'—'}</div></div>
      </div>
    </div>
    ${a.notes?`<div class="detail-section"><h3>Notes</h3><p style="font-size:13px;color:var(--muted)">${a.notes}</p></div>`:''}
    <div class="market-banner">
      <div><div class="label">Machine condition</div><div style="font-weight:600;margin-top:2px" class="cond-${(a.machine_condition||'good').toLowerCase()}">${a.machine_condition||'—'}</div></div>
      <div style="text-align:right"><div class="label">Current market value</div><div class="value">${a.market_value?'PKR '+Number(a.market_value).toLocaleString():'N/A'}</div></div>
    </div>
    <div class="modal-actions">
      <button class="btn btn-danger" onclick="deleteAsset(${a.id},'${a.asset_tag}')">Delete</button>
      <button class="btn" onclick="openEdit(${a.id})">Edit asset</button>
    </div>`;
  showModal();
}

// --- Edit / Add modal ---
async function openEdit(id) {
  editingId = id;
  const a = await fetch('/api/assets/'+id).then(r=>r.json());
  document.getElementById('modal-title').textContent = 'Edit: ' + a.asset_tag;
  document.getElementById('modal-body').innerHTML = buildForm(a);
  showModal();
}

function openAddModal() {
  editingId = null;
  document.getElementById('modal-title').textContent = 'Add New Asset';
  document.getElementById('modal-body').innerHTML = buildForm({});
  showModal();
}

function buildForm(a) {
  return `<div class="form-grid">
    <div class="form-group"><label>Asset Tag *</label><input id="f-asset_tag" value="${a.asset_tag||''}" placeholder="DSK-OZIG-XXX"></div>
    <div class="form-group"><label>Serial</label><input id="f-serial" value="${a.serial||''}"></div>
    <div class="form-group"><label>Model</label><input id="f-model" value="${a.model||''}"></div>
    <div class="form-group"><label>Category</label>
      <select id="f-category">
        <option ${a.category==='Desktop'?'selected':''}>Desktop</option>
        <option ${a.category==='Laptop'?'selected':''}>Laptop</option>
      </select>
    </div>
    <div class="form-group"><label>Manufacturer</label><input id="f-manufacturer" value="${a.manufacturer||''}"></div>
    <div class="form-group"><label>Supplier</label><input id="f-supplier" value="${a.supplier||''}"></div>
    <div class="form-group"><label>Purchase date</label><input id="f-purchase_date" type="date" value="${a.purchase_date||''}"></div>
    <div class="form-group"><label>Purchase cost (PKR)</label><input id="f-purchase_cost" type="number" value="${a.purchase_cost||''}"></div>
    <div class="form-group"><label>Assigned to</label><input id="f-assign_to" value="${a.assign_to||''}"></div>
    <div class="form-group"><label>Previously assigned</label><input id="f-prev_assigned" value="${a.prev_assigned||''}"></div>
    <div class="form-group full"><label>Location</label><input id="f-location" value="${a.location||''}"></div>
    <div class="form-group"><label>RAM</label><input id="f-ram" value="${a.ram||''}" placeholder="32GB"></div>
    <div class="form-group"><label>SSD</label><input id="f-ssd" value="${a.ssd||''}" placeholder="512GB"></div>
    <div class="form-group"><label>HDD</label><input id="f-hdd" value="${a.hdd||''}" placeholder="1TB"></div>
    <div class="form-group"><label>GPU</label><input id="f-gpu" value="${a.gpu||''}"></div>
    <div class="form-group full"><label>Processor</label><input id="f-processor" value="${a.processor||''}"></div>
    <div class="form-group"><label>Condition</label>
      <select id="f-machine_condition">
        <option ${a.machine_condition==='Good'?'selected':''}>Good</option>
        <option ${a.machine_condition==='Excellent'?'selected':''}>Excellent</option>
        <option ${a.machine_condition==='Poor'?'selected':''}>Poor</option>
      </select>
    </div>
    <div class="form-group"><label>Market value (PKR)</label><input id="f-market_value" type="number" value="${a.market_value||''}"></div>
    <div class="form-group"><label>Status</label>
      <select id="f-status">
        <option ${a.status==='Ready to Deploy'?'selected':''}>Ready to Deploy</option>
        <option ${a.status==='In Use'?'selected':''}>In Use</option>
        <option ${a.status==='Faulty'?'selected':''}>Faulty</option>
        <option ${a.status==='Retired'?'selected':''}>Retired</option>
      </select>
    </div>
    <div class="form-group full"><label>Notes</label><textarea id="f-notes">${a.notes||''}</textarea></div>
  </div>
  <div class="modal-actions">
    <button class="btn" onclick="document.getElementById('modal-overlay').style.display='none'">Cancel</button>
    <button class="btn btn-primary" onclick="saveAsset()">Save asset</button>
  </div>`;
}

function getFormData() {
  const fields = ['asset_tag','serial','model','category','manufacturer','supplier','purchase_date',
    'purchase_cost','assign_to','prev_assigned','location','ram','ssd','hdd','gpu','processor',
    'machine_condition','market_value','status','notes'];
  const data = {};
  fields.forEach(f => {
    const el = document.getElementById('f-'+f);
    if (el) data[f] = el.value.trim();
  });
  return data;
}

async function saveAsset() {
  const data = getFormData();
  if (!data.asset_tag) { alert('Asset tag is required.'); return; }
  const url = editingId ? '/api/assets/'+editingId : '/api/assets';
  const method = editingId ? 'PUT' : 'POST';
  const res = await fetch(url, { method, headers:{'Content-Type':'application/json'}, body: JSON.stringify(data) });
  const json = await res.json();
  if (json.error) { alert('Error: '+json.error); return; }
  document.getElementById('modal-overlay').style.display = 'none';
  loadAssets();
}

async function deleteAsset(id, tag) {
  if (!confirm(`Delete asset ${tag}? This cannot be undone.`)) return;
  await fetch('/api/assets/'+id, { method:'DELETE' });
  document.getElementById('modal-overlay').style.display = 'none';
  loadAssets();
}

function showModal() {
  document.getElementById('modal-overlay').style.display = 'flex';
}

function closeModal(e) {
  if (e.target === document.getElementById('modal-overlay'))
    document.getElementById('modal-overlay').style.display = 'none';
}

// Init
showView('dashboard');
