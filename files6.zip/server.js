const express = require('express');
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const xlsx = require('node-xlsx');
const createAuth = require('./auth');

const app = express();
const PORT = process.env.PORT || 3000;

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

const db = new Database(path.join(DATA_DIR, 'inventory.db'));

// ── Authentication (creates users/sessions tables; seeds the admin user on first run) ──
const auth = createAuth(db);
const seeded = auth.ensureAdmin();
if (seeded) {
  console.log(seeded.usedDefault
    ? "Created admin user 'admin' with the default password. It must be changed at first login."
    : "Created admin user 'admin' using OZI_ADMIN_PASSWORD.");
}
setInterval(() => auth.purgeExpired(), 60 * 60 * 1000).unref();

// ── Schema ────────────────────────────────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company TEXT DEFAULT 'OZI-G',
    asset_tag TEXT UNIQUE NOT NULL,
    serial TEXT,
    model TEXT,
    category TEXT,
    status TEXT DEFAULT 'Ready to Deploy',
    location TEXT,
    manufacturer TEXT,
    supplier TEXT,
    purchase_date TEXT,
    purchase_cost REAL,
    assign_to TEXT,
    prev_assigned TEXT,
    ram TEXT,
    processor TEXT,
    ssd TEXT,
    hdd TEXT,
    gpu TEXT,
    machine_condition TEXT DEFAULT 'Good',
    market_value REAL,
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS audit_log (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    ts        TEXT NOT NULL,
    user_id   INTEGER,
    username  TEXT,
    module    TEXT NOT NULL,          -- 'IT' | 'NON_IT'
    action    TEXT NOT NULL,          -- 'add' | 'edit' | 'delete'
    item_id   TEXT,
    item_tag  TEXT,
    item_name TEXT,
    company   TEXT,
    changes   TEXT                    -- JSON: [{f,from,to}]
  );
  CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(ts DESC);

  CREATE TABLE IF NOT EXISTS kv (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS office_assets (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_tag      TEXT UNIQUE NOT NULL,
    name           TEXT NOT NULL,
    category       TEXT,
    company        TEXT,
    location       TEXT,
    floor          TEXT,
    quantity       INTEGER NOT NULL DEFAULT 1,
    item_condition TEXT DEFAULT 'Good',
    status         TEXT DEFAULT 'In Use',
    assigned_to    TEXT,
    vendor         TEXT,
    serial_no      TEXT,
    purchase_date  TEXT,
    unit_cost      REAL,
    warranty_expiry TEXT,
    notes          TEXT,
    created_at     TEXT DEFAULT (datetime('now')),
    updated_at     TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS custom_fields (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    field_key  TEXT UNIQUE NOT NULL,
    label      TEXT NOT NULL,
    field_type TEXT NOT NULL DEFAULT 'text',
    options    TEXT,
    required   INTEGER DEFAULT 0,
    sort_order INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS asset_custom_values (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id   INTEGER NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
    field_key  TEXT NOT NULL,
    value      TEXT,
    UNIQUE(asset_id, field_key)
  );
`);

// ── Seed ─────────────────────────────────────────────────────
const count = db.prepare('SELECT COUNT(*) as c FROM assets').get();
if (count.c === 0) {
  const ins = db.prepare(`INSERT OR IGNORE INTO assets
    (company,asset_tag,serial,model,category,status,location,manufacturer,supplier,
     purchase_date,purchase_cost,assign_to,prev_assigned,ram,processor,ssd,hdd,gpu,machine_condition,market_value)
    VALUES (@company,@asset_tag,@serial,@model,@category,@status,@location,@manufacturer,@supplier,
     @purchase_date,@purchase_cost,@assign_to,@prev_assigned,@ram,@processor,@ssd,@hdd,@gpu,@machine_condition,@market_value)`);
  const seed = db.transaction(rows => { for (const r of rows) ins.run(r); });
  seed([
    {company:'OZI-G',asset_tag:'DSK-OZIG-001',serial:'5JYRF2S',model:'Precision T3600',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'FREE',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'',ram:'16GB',processor:'Quad Core E5-1620 3.60GHz',ssd:'480GB',hdd:'',gpu:'NVIDIA GeForce GTX 1060 6GB',machine_condition:'Good',market_value:45000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-002',serial:'CP51CD2',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Z.I Computers',purchase_date:'2020-11-09',purchase_cost:138000,assign_to:'Aftab Ali',prev_assigned:'OZI-G',ram:'32GB',processor:'Intel Xeon E5 1650 V3 @ 3.50GHz',ssd:'480GB',hdd:'1TB',gpu:'Radeon RX 580 8GB',machine_condition:'Good',market_value:70000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-003',serial:'HC1BDH2',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Dabeer Irfan',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'',ram:'32GB',processor:'Intel Xeon E5-2660 v3 @ 2.60GHz',ssd:'240GB',hdd:'2TB',gpu:'NVIDIA GTX 1050 Ti 4GB',machine_condition:'Good',market_value:65000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-004',serial:'59R0KB2',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Z.I Computers',purchase_date:'2022-09-19',purchase_cost:77000,assign_to:'Daniyal Jawad',prev_assigned:'OZI-G',ram:'32GB',processor:'Intel Xeon E5-2660 V3 @ 2.60GHz',ssd:'480GB',hdd:'1TB',gpu:'',machine_condition:'Good',market_value:65000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-005',serial:'37Y7XK2',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Z.I Computers',purchase_date:'2022-09-19',purchase_cost:81000,assign_to:'Muhammad Faiq',prev_assigned:'OZI-G',ram:'32GB',processor:'Intel Xeon E5-2658 V3 @ 2.20GHz',ssd:'480GB',hdd:'1TB, 1TB',gpu:'AMD RX 580 Series',machine_condition:'Good',market_value:65000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-006',serial:'5VZYF2S',model:'Precision T7600',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'FREE / In IT Inventory',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'',ram:'32GB',processor:'Octa Core E5-2660 @ 2.20GHz x2',ssd:'480GB',hdd:'',gpu:'NVIDIA GeForce GTX 1060 6GB',machine_condition:'Good',market_value:90000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-007',serial:'J3TBC2S',model:'Precision T5500',category:'Desktop',status:'Faulty',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'',purchase_date:null,purchase_cost:null,assign_to:'FAULTY',prev_assigned:'',ram:'16GB',processor:'Intel Xeon E5645 Hexa Core 2.4GHz',ssd:'',hdd:'',gpu:'',machine_condition:'Poor',market_value:30000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-008',serial:'6LVCJB2',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Halta Enterprises',purchase_date:'2022-09-19',purchase_cost:82000,assign_to:'Muhammad Usama Irshad',prev_assigned:'Playcraft',ram:'32GB',processor:'Intel Xeon 2670 v3',ssd:'512GB',hdd:'500GB',gpu:'NVIDIA GTX 1060 3GB',machine_condition:'Good',market_value:60000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-010',serial:'R8PG59X',model:'Thinkstation D20',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'Lenovo',supplier:'FREE / In IT Inventory',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'AppWing',ram:'16GB',processor:'Intel Xeon X5690 / 3.33GHz (2 processors)',ssd:'256GB',hdd:'1TB',gpu:'NVIDIA GeForce GTX 1060 6GB',machine_condition:'Good',market_value:70000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-011',serial:'FLQ0ZY1',model:'Precision T3600',category:'Desktop',status:'Ready to Deploy',location:'OZI-LABS',manufacturer:'DELL',supplier:'OUT OF OFFICE',purchase_date:null,purchase_cost:null,assign_to:'OZI-LABS',prev_assigned:'',ram:'16GB',processor:'Intel Xeon E5-1660 @ 3.30GHz',ssd:'256GB',hdd:'1TB',gpu:'NVIDIA GeForce GTX 1050 Ti',machine_condition:'Good',market_value:60000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-012',serial:'8C6WJS1',model:'Precision T5500',category:'Desktop',status:'Ready to Deploy',location:'OZI-LABS',manufacturer:'DELL',supplier:'OUT OF OFFICE',purchase_date:null,purchase_cost:null,assign_to:'OZI-LABS',prev_assigned:'',ram:'32GB',processor:'Intel Xeon X5675 @ 3.07GHz',ssd:'256GB',hdd:'1TB',gpu:'NVIDIA GeForce GTX 1050 4GB TI',machine_condition:'Good',market_value:55000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-013',serial:'2UA8112514',model:'Z440',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'HP',supplier:'Game & Greeks',purchase_date:'2022-09-19',purchase_cost:128500,assign_to:'Ex-Nauman Aslam',prev_assigned:'OZI-G',ram:'32GB',processor:'Intel Xeon E5-2670 v3 @ 2.30GHz',ssd:'512GB',hdd:'2TB',gpu:'NVIDIA GeForce GTX 1060 3GB (Dual Fan)',machine_condition:'Good',market_value:70000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-014',serial:'INVALID',model:'Asus Gaming Board',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'Asus',supplier:"Gamer's Bay",purchase_date:'2022-08-03',purchase_cost:585000,assign_to:'Rendering Machine / Local VM',prev_assigned:'AppWing',ram:'64GB',processor:'Intel Core i9-11900k 11th Gen',ssd:'NVMe M.2 1TB',hdd:'2TB',gpu:'NVIDIA RTX 3060 12GB',machine_condition:'Excellent',market_value:385000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-015',serial:'F7GT182',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Salar Jahan Wallah',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'',ram:'32GB',processor:'Intel Xeon E5-2673 v3 @ 2.40GHz',ssd:'500NVMe',hdd:'1TB',gpu:'Zotac GTX 1060 3GB',machine_condition:'Good',market_value:60000},
    {company:'OZI-G',asset_tag:'LPT-OZIG-001',serial:'PF2PJ4PP',model:'82FG',category:'Laptop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'Lenovo',supplier:'Century Laptops',purchase_date:'2022-09-19',purchase_cost:151000,assign_to:'Ghulam Ahmad',prev_assigned:'OZI-G',ram:'16GB',processor:'Intel Core i7 11th Generation',ssd:'512GB',hdd:'',gpu:'NVIDIA MX 450',machine_condition:'Good',market_value:80000},
    {company:'OZI-G',asset_tag:'LPT-OZIG-002',serial:'C02W81Z0HTDF',model:'MacBook Pro 2017 15-inch',category:'Laptop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'Apple',supplier:'Laptop World',purchase_date:'2017-01-01',purchase_cost:280000,assign_to:'Haseeb Ahmed',prev_assigned:'OZI-G',ram:'16GB',processor:'Intel Core i7 @ 3.10GHz',ssd:'1TB',hdd:'',gpu:'4GB',machine_condition:'Good',market_value:185000},
    {company:'OZI-G',asset_tag:'LPT-OZIG-004',serial:'PF07MRV2',model:'80 E5',category:'Laptop',status:'Ready to Deploy',location:'OZI-LABS',manufacturer:'Lenovo',supplier:'OUT OF OFFICE',purchase_date:null,purchase_cost:null,assign_to:'OZI-LABS',prev_assigned:'',ram:'8GB',processor:'Intel Core i5',ssd:'256GB',hdd:'500GB',gpu:'AMD Radeon R5 M330',machine_condition:'Good',market_value:null},
    {company:'OZI-G',asset_tag:'LPT-OZIG-005',serial:'1RPQPH3',model:'Inspiron 3501',category:'Laptop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Century Laptops',purchase_date:'2022-01-12',purchase_cost:170000,assign_to:'Abdul Saboor',prev_assigned:'OZI-Theta',ram:'16GB',processor:'Intel Core i7-1165G7 @ 2.80GHz',ssd:'512GB',hdd:'',gpu:'NVIDIA GeForce MX330',machine_condition:'Good',market_value:110000},
    {company:'OZI-G',asset_tag:'LPT-OZIG-006',serial:'111X3G3',model:'Inspiron 3501',category:'Laptop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Century Laptops',purchase_date:null,purchase_cost:170000,assign_to:'Salman Sheikh',prev_assigned:'OZI-G',ram:'16GB',processor:'Intel Core i7 11th Generation',ssd:'512GB',hdd:'',gpu:'MX330 2GB',machine_condition:'Good',market_value:120000},
    {company:'OZI-G',asset_tag:'LPT-OZIG-008',serial:'5CG424DTW3',model:'ProBook 350 G1',category:'Laptop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'HP',supplier:'Hamza / Sheikh Sb',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'',ram:'8GB',processor:'Intel Core i5-4200U @ 1.60GHz',ssd:'256GB',hdd:'500GB',gpu:'AMD HD 8600MS 2GB',machine_condition:'Good',market_value:45000},
  ]);
}

app.set('trust proxy', 'loopback'); // real client IP when Nginx is in front (for login lockout)
app.use(express.json({ limit: '25mb' })); // settings hold base64 logos / login background

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Cache-Control', 'no-store');
  next();
});

// ── Login routes are public; EVERYTHING after auth.requireAuth needs a valid session ──
app.post('/api/login', auth.login);
app.post('/api/logout', auth.logout);
app.use(auth.requireAuth);
app.get('/api/me', auth.me);
app.post('/api/change-password', auth.changePassword);

app.use(express.static(path.join(__dirname, 'public')));


// ══════════════════════════════════════════════════════════════
//  Asset Register / Settings / Users / Employees API
//  (what public/index.html talks to)
// ══════════════════════════════════════════════════════════════
const kvGet = (key, fallback) => {
  const row = db.prepare('SELECT value FROM kv WHERE key = ?').get(key);
  if (!row) return fallback;
  try { return JSON.parse(row.value); } catch (e) { return fallback; }
};
const kvSet = (key, val) =>
  db.prepare('INSERT INTO kv (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value')
    .run(key, JSON.stringify(val));

const isAdmin = req => req.user && req.user.role === 'admin';
const requireAdmin = (req, res, next) =>
  isAdmin(req) ? next() : res.status(403).json({ error: 'Admin access required' });

const emptyData = () => ({ companies: [], assets: [], nextId: 1 });
const loadData = () => {
  const d = kvGet('data', null) || emptyData();
  if (!Array.isArray(d.companies)) d.companies = [];
  if (!Array.isArray(d.assets)) d.assets = [];
  if (!d.nextId) d.nextId = 1;
  return d;
};

// ── Audit trail (append-only: there is deliberately no route that edits or deletes log rows) ──
const AUDIT_CLIP = 200;
const clip = v => { const x = v == null ? '' : String(v); return x.length > AUDIT_CLIP ? x.slice(0, AUDIT_CLIP) + '…' : x; };

const IT_LABELS = {
  type: 'Type', brand: 'Brand', model: 'Model', deviceSpecs: 'Device Specs', gpu: 'GPU', ram: 'RAM', ssd: 'SSD', hdd: 'HDD',
  serial: 'Serial No', assetTag: 'Asset Tag', assetTag2: 'Asset Tag 2', systemTag: 'System Tag', prevTag: 'Previous Tag',
  company: 'Company', location: 'Location', floor: 'Floor', status: 'Status', assignedTo: 'Assigned To', lastAssigned: 'Last Assigned',
  vendorName: 'Vendor', vendorContact: 'Vendor Contact', purchasePrice: 'Purchase Price', marketValue: 'Market Value',
  purchaseDate: 'Purchase Date', warranty: 'Warranty', notes: 'Notes',
};
const IT_SNAPSHOT = ['type', 'brand', 'model', 'serial', 'company', 'location', 'floor', 'status', 'assignedTo'];
const OA_LABELS = {
  name: 'Item', category: 'Category', asset_tag: 'Asset Tag', company: 'Company', floor: 'Floor', location: 'Location',
  quantity: 'Quantity', item_condition: 'Condition', status: 'Status', assigned_to: 'Assigned To', vendor: 'Vendor',
  serial_no: 'Serial No', purchase_date: 'Purchase Date', unit_cost: 'Unit Cost', warranty_expiry: 'Warranty Expiry', notes: 'Notes',
};
const OA_SNAPSHOT = ['category', 'quantity', 'company', 'location', 'floor', 'status', 'assigned_to'];

function auditDiff(before, after, labels) {
  const out = [];
  for (const k of Object.keys(labels)) {
    const a = before[k] == null ? '' : String(before[k]);
    const b = after[k] == null ? '' : String(after[k]);
    if (a !== b) out.push({ f: labels[k], from: clip(a), to: clip(b) });
  }
  return out;
}
function auditSnapshot(obj, keys, labels, side) {
  return keys.filter(k => obj[k] != null && String(obj[k]) !== '')
             .map(k => ({ f: labels[k], from: side === 'from' ? clip(obj[k]) : '', to: side === 'to' ? clip(obj[k]) : '' }));
}
function auditLog(req, e) {
  db.prepare(`INSERT INTO audit_log (ts,user_id,username,module,action,item_id,item_tag,item_name,company,changes)
              VALUES (?,?,?,?,?,?,?,?,?,?)`)
    .run(new Date().toISOString(), req.user.id, req.user.username, e.module, e.action,
         e.item_id == null ? '' : String(e.item_id), clip(e.tag), clip(e.name), clip(e.company),
         e.changes && e.changes.length ? JSON.stringify(e.changes) : null);
}
const itTag  = a => a.assetTag || a.systemTag || a.serial || ('#' + a.id);
const itName = a => [a.type, a.brand, a.model].filter(Boolean).join(' ');

// IT assets are saved as one JSON blob, so work out what changed by comparing stored vs incoming
function auditAssetChanges(stored, next) {
  const before = new Map(stored.assets.map(a => [String(a.id), a]));
  const after  = new Map(next.assets.map(a => [String(a.id), a]));
  const rows = [];
  for (const [id, a] of after) {
    const b = before.get(id);
    if (!b) {
      rows.push({ module: 'IT', action: 'add', item_id: id, tag: itTag(a), name: itName(a), company: a.company,
                  changes: auditSnapshot(a, IT_SNAPSHOT, IT_LABELS, 'to') });
    } else {
      const ch = auditDiff(b, a, IT_LABELS);
      if (ch.length) rows.push({ module: 'IT', action: 'edit', item_id: id, tag: itTag(a), name: itName(a), company: a.company, changes: ch });
    }
  }
  for (const [id, b] of before) {
    if (!after.has(id)) {
      rows.push({ module: 'IT', action: 'delete', item_id: id, tag: itTag(b), name: itName(b), company: b.company,
                  changes: auditSnapshot(b, IT_SNAPSHOT, IT_LABELS, 'from') });
    }
  }
  return rows;
}

// ── Branding for the login screen ──
app.get('/api/branding', (req, res) => {
  const s = kvGet('settings', {});
  res.json({ appName: s.appName, companyName: s.companyName, address: s.address,
             mainLogo: s.mainLogo, loginBackground: s.loginBackground });
});

// ── Main data blob (companies, assets, employees) ──
app.get('/api/data', (req, res) => {
  const d = loadData();
  const co = req.user.company;
  if (co && !isAdmin(req)) {            // company-restricted user only ever receives their own company
    d.companies = d.companies.filter(c => c === co);
    d.assets = d.assets.filter(a => a.company === co);
  }
  res.json(d);
});

app.post('/api/data', (req, res) => {
  const inc = req.body;
  if (!inc || typeof inc !== 'object' || !Array.isArray(inc.companies) || !Array.isArray(inc.assets)) {
    return res.status(400).json({ error: 'Invalid data' });
  }
  const stored = loadData();
  const co = req.user.company;
  let next = { ...stored, ...inc };

  if (co && !isAdmin(req)) {
    // Restricted user: may only change their own company's assets; everything else is kept as stored
    next.assets = [
      ...stored.assets.filter(a => a.company !== co),
      ...inc.assets.filter(a => a.company === co),
    ];
    next.companies = stored.companies;
  }
  if (!isAdmin(req)) {
    // Junior = view + add only: block any save that removes things
    const storedEmp = Array.isArray(stored.employees) ? stored.employees.length : 0;
    const nextEmp = Array.isArray(next.employees) ? next.employees.length : 0;
    const sameCompanies = stored.companies.length === next.companies.length &&
                          stored.companies.every(c => next.companies.includes(c));
    if (next.assets.length < stored.assets.length || nextEmp < storedEmp || !sameCompanies) {
      return res.status(403).json({ error: 'Your role cannot delete or change companies' });
    }
  }
  const maxId = next.assets.reduce((m, a) => Math.max(m, Number(a.id) || 0), 0);
  next.nextId = Math.max(Number(next.nextId) || 1, maxId + 1);
  const entries = auditAssetChanges(stored, next);
  db.transaction(() => { kvSet('data', next); entries.forEach(e => auditLog(req, e)); })();
  res.json({ success: true });
});

app.delete('/api/company/:name', requireAdmin, (req, res) => {
  const name = req.params.name;
  const d = loadData();
  const removed = d.assets.filter(a => a.company === name);
  d.companies = d.companies.filter(c => c !== name);
  d.assets = d.assets.filter(a => a.company !== name);
  db.transaction(() => {
    kvSet('data', d);
    removed.forEach(a => auditLog(req, { module: 'IT', action: 'delete', item_id: a.id, tag: itTag(a), name: itName(a), company: a.company,
      changes: [{ f: 'Reason', from: 'Company "' + name + '" deleted', to: '' }, ...auditSnapshot(a, IT_SNAPSHOT, IT_LABELS, 'from')] }));
  })();
  const s = kvGet('settings', {});
  if (s.companyLogos && s.companyLogos[name]) { delete s.companyLogos[name]; kvSet('settings', s); }
  res.json({ success: true });
});

// ── Settings ──
app.get('/api/settings', (req, res) => {
  const s = kvGet('settings', {});
  if (!isAdmin(req) && s.slackWebhook) s.slackWebhook = '(configured)'; // never expose the webhook to non-admins
  res.json(s);
});
app.post('/api/settings', requireAdmin, (req, res) => {
  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
    return res.status(400).json({ error: 'Invalid settings' });
  }
  kvSet('settings', req.body);
  res.json({ success: true });
});

// ── Slack proxy (browser can't call Slack directly because of CORS) ──
app.post('/api/slack', async (req, res) => {
  const { webhook, payload } = req.body || {};
  const url = isAdmin(req) && webhook ? webhook : kvGet('settings', {}).slackWebhook;
  if (typeof url !== 'string' || !url.startsWith('https://hooks.slack.com/')) {
    return res.status(400).json({ error: 'Invalid Slack webhook' });
  }
  try {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload || {}) });
    res.status(r.ok ? 200 : 502).json({ ok: r.ok });
  } catch (e) { res.status(502).json({ ok: false }); }
});

// ── Users ──
const userRow = u => ({ id: u.id, name: u.name || u.username, username: u.username, role: u.role, company: u.company || '' });
const adminCount = () => db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'admin'").get().c;

app.get('/api/users', requireAdmin, (req, res) => {
  res.json(db.prepare('SELECT id, username, name, role, company FROM users ORDER BY id').all().map(userRow));
});

app.post('/api/users', requireAdmin, (req, res) => {
  const { name, username, password, role, company } = req.body || {};
  if (!name || !username || !password) return res.status(400).json({ error: 'Name, username and password are required' });
  if (!/^[A-Za-z0-9._@-]{3,40}$/.test(username)) return res.status(400).json({ error: 'Username must be 3-40 characters (letters, numbers . _ - @)' });
  if (String(password).length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  const r = role === 'admin' ? 'admin' : 'junior';
  if (db.prepare('SELECT 1 FROM users WHERE username = ?').get(username)) return res.status(400).json({ error: 'Username already exists' });
  const { salt, hash } = createAuth.hashPassword(password);
  db.prepare('INSERT INTO users (username, name, password_hash, salt, role, company, must_change) VALUES (?, ?, ?, ?, ?, ?, 0)')
    .run(username, String(name).trim(), hash, salt, r, r === 'admin' ? '' : (company || ''));
  res.json({ success: true });
});

app.put('/api/users/:id', (req, res) => {
  const id = Number(req.params.id);
  const self = id === req.user.id;
  if (!isAdmin(req) && !self) return res.status(403).json({ error: 'Admin access required' });
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (!u) return res.status(404).json({ error: 'User not found' });
  const b = req.body || {};

  let { name, username, role, company } = u;
  if (isAdmin(req)) {
    name = b.name ? String(b.name).trim() : (u.name || u.username);
    if (b.username && b.username !== u.username) {
      if (!/^[A-Za-z0-9._@-]{3,40}$/.test(b.username)) return res.status(400).json({ error: 'Invalid username' });
      if (db.prepare('SELECT 1 FROM users WHERE username = ? AND id <> ?').get(b.username, id)) return res.status(400).json({ error: 'Username already exists' });
      username = b.username;
    }
    role = b.role === 'admin' ? 'admin' : 'junior';
    if (u.role === 'admin' && role !== 'admin' && adminCount() <= 1) return res.status(400).json({ error: 'Cannot demote the last admin' });
    company = role === 'admin' ? '' : (b.company || '');
  }
  db.prepare('UPDATE users SET name = ?, username = ?, role = ?, company = ? WHERE id = ?').run(name, username, role, company, id);

  if (b.password) {
    if (String(b.password).length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
    const { salt, hash } = createAuth.hashPassword(b.password);
    db.prepare('UPDATE users SET password_hash = ?, salt = ?, must_change = 0 WHERE id = ?').run(hash, salt, id);
    if (!self) db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id);   // force the other person to sign in again
  }
  res.json({ success: true });
});

app.delete('/api/users/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (id === req.user.id) return res.status(400).json({ error: 'You cannot delete your own account' });
  const u = db.prepare('SELECT role FROM users WHERE id = ?').get(id);
  if (!u) return res.status(404).json({ error: 'User not found' });
  if (u.role === 'admin' && adminCount() <= 1) return res.status(400).json({ error: 'Cannot delete the last admin' });
  db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id);
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
  res.json({ success: true });
});



// ── Activity history (admin only, read-only) ──
app.get('/api/audit', requireAdmin, (req, res) => {
  const { module, action, user, q, from, to } = req.query;
  const limit = Math.min(Math.max(parseInt(req.query.limit) || 50, 1), 10000);
  const offset = Math.max(parseInt(req.query.offset) || 0, 0);
  let where = ' WHERE 1=1';
  const p = [];
  if (module === 'IT' || module === 'NON_IT') { where += ' AND module = ?'; p.push(module); }
  if (['add', 'edit', 'delete'].includes(action)) { where += ' AND action = ?'; p.push(action); }
  if (user) { where += ' AND username = ?'; p.push(String(user)); }
  if (from && !isNaN(Date.parse(from))) { where += ' AND ts >= ?'; p.push(new Date(from).toISOString()); }
  if (to && !isNaN(Date.parse(to)))     { where += ' AND ts <= ?'; p.push(new Date(to).toISOString()); }
  if (q) {
    where += ' AND (item_tag LIKE ? OR item_name LIKE ? OR username LIKE ? OR company LIKE ? OR changes LIKE ?)';
    const like = '%' + String(q).replace(/[%_]/g, m => '\\' + m) + '%';
    where = where.replace(/LIKE \?/g, "LIKE ? ESCAPE '\\'");
    p.push(like, like, like, like, like);
  }
  const total = db.prepare('SELECT COUNT(*) AS c FROM audit_log' + where).get(...p).c;
  const rows = db.prepare('SELECT * FROM audit_log' + where + ' ORDER BY id DESC LIMIT ? OFFSET ?').all(...p, limit, offset)
    .map(r => ({ ...r, changes: r.changes ? JSON.parse(r.changes) : [] }));
  const users = db.prepare('SELECT DISTINCT username FROM audit_log ORDER BY username').all().map(r => r.username);
  res.json({ rows, total, users });
});

// ── Office Assets (non-IT items: furniture, AC, appliances, vehicles …) — ADMIN ONLY ──
const OA_STATUS = ['In Use', 'Spare / Stored', 'Under Repair', 'Disposed'];
const OA_COND   = ['New', 'Good', 'Fair', 'Poor'];
const oaStr = (v, max = 200) => (v == null ? '' : String(v).trim().slice(0, max));
const oaDate = v => { const x = oaStr(v, 10); return /^\d{4}-\d{2}-\d{2}$/.test(x) ? x : ''; };

function oaClean(b) {
  const qty = Math.floor(Number(b.quantity));
  const cost = b.unit_cost === '' || b.unit_cost == null ? null : Number(b.unit_cost);
  return {
    asset_tag: oaStr(b.asset_tag, 40),
    name: oaStr(b.name),
    category: oaStr(b.category, 60),
    company: oaStr(b.company, 80),
    location: oaStr(b.location, 120),
    floor: oaStr(b.floor, 40),
    quantity: Number.isFinite(qty) && qty >= 1 ? Math.min(qty, 100000) : 1,
    item_condition: OA_COND.includes(b.item_condition) ? b.item_condition : 'Good',
    status: OA_STATUS.includes(b.status) ? b.status : 'In Use',
    assigned_to: oaStr(b.assigned_to, 120),
    vendor: oaStr(b.vendor, 120),
    serial_no: oaStr(b.serial_no, 80),
    purchase_date: oaDate(b.purchase_date),
    unit_cost: Number.isFinite(cost) && cost >= 0 ? cost : null,
    warranty_expiry: oaDate(b.warranty_expiry),
    notes: oaStr(b.notes, 1000),
  };
}

app.get('/api/office-assets', requireAdmin, (req, res) => {
  res.json(db.prepare('SELECT * FROM office_assets ORDER BY id DESC').all());
});

app.post('/api/office-assets', requireAdmin, (req, res) => {
  const a = oaClean(req.body || {});
  if (!a.name) return res.status(400).json({ error: 'Item name is required' });
  try {
    const tag = a.asset_tag || 'TMP-' + require('crypto').randomBytes(6).toString('hex');
    const info = db.prepare(`INSERT INTO office_assets
      (asset_tag,name,category,company,location,floor,quantity,item_condition,status,assigned_to,vendor,serial_no,purchase_date,unit_cost,warranty_expiry,notes)
      VALUES (@tag,@name,@category,@company,@location,@floor,@quantity,@item_condition,@status,@assigned_to,@vendor,@serial_no,@purchase_date,@unit_cost,@warranty_expiry,@notes)`)
      .run({ ...a, tag });
    const id = Number(info.lastInsertRowid);
    if (!a.asset_tag) db.prepare('UPDATE office_assets SET asset_tag = ? WHERE id = ?').run('OFC-' + String(id).padStart(4, '0'), id);
    const row = db.prepare('SELECT * FROM office_assets WHERE id = ?').get(id);
    auditLog(req, { module: 'NON_IT', action: 'add', item_id: id, tag: row.asset_tag, name: row.name, company: row.company,
                    changes: auditSnapshot(row, OA_SNAPSHOT, OA_LABELS, 'to') });
    res.json({ success: true, id });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(400).json({ error: 'Asset tag already exists' });
    console.error(e); res.status(500).json({ error: 'Could not save item' });
  }
});

app.put('/api/office-assets/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const cur = db.prepare('SELECT * FROM office_assets WHERE id = ?').get(id);
  if (!cur) return res.status(404).json({ error: 'Item not found' });
  const a = oaClean(req.body || {});
  if (!a.name) return res.status(400).json({ error: 'Item name is required' });
  if (!a.asset_tag) a.asset_tag = cur.asset_tag;
  try {
    db.prepare(`UPDATE office_assets SET asset_tag=@asset_tag,name=@name,category=@category,company=@company,location=@location,floor=@floor,
      quantity=@quantity,item_condition=@item_condition,status=@status,assigned_to=@assigned_to,vendor=@vendor,serial_no=@serial_no,
      purchase_date=@purchase_date,unit_cost=@unit_cost,warranty_expiry=@warranty_expiry,notes=@notes,updated_at=datetime('now') WHERE id=@id`)
      .run({ ...a, id });
    const ch = auditDiff(cur, a, OA_LABELS);
    if (ch.length) auditLog(req, { module: 'NON_IT', action: 'edit', item_id: id, tag: a.asset_tag, name: a.name, company: a.company, changes: ch });
    res.json({ success: true });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(400).json({ error: 'Asset tag already exists' });
    console.error(e); res.status(500).json({ error: 'Could not save item' });
  }
});

app.delete('/api/office-assets/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const row = db.prepare('SELECT * FROM office_assets WHERE id = ?').get(id);
  if (!row) return res.json({ error: 'Item not found' });
  db.transaction(() => {
    db.prepare('DELETE FROM office_assets WHERE id = ?').run(id);
    auditLog(req, { module: 'NON_IT', action: 'delete', item_id: id, tag: row.asset_tag, name: row.name, company: row.company,
                    changes: auditSnapshot(row, OA_SNAPSHOT, OA_LABELS, 'from') });
  })();
  res.json({ success: true });
});

// ── Helper: build filter SQL ──────────────────────────────────
function buildFilterSQL(query) {
  const { q, category, condition, status, manufacturer, location, ram, page = 1, limit = 15 } = query;
  let sql = 'SELECT * FROM assets WHERE 1=1';
  let countSQL = 'SELECT COUNT(*) as c FROM assets WHERE 1=1';
  const params = [];

  if (q) {
    const clause = ' AND (asset_tag LIKE ? OR model LIKE ? OR assign_to LIKE ? OR serial LIKE ? OR manufacturer LIKE ? OR gpu LIKE ? OR processor LIKE ? OR location LIKE ?)';
    sql += clause; countSQL += clause;
    const like = `%${q}%`;
    params.push(like,like,like,like,like,like,like,like);
  }
  if (category && category !== 'All')    { const c=' AND category=?';          sql+=c; countSQL+=c; params.push(category); }
  if (condition && condition !== 'All')  { const c=' AND machine_condition=?';  sql+=c; countSQL+=c; params.push(condition); }
  if (status && status !== 'All')        { const c=' AND status=?';             sql+=c; countSQL+=c; params.push(status); }
  if (manufacturer && manufacturer !== 'All') { const c=' AND manufacturer=?'; sql+=c; countSQL+=c; params.push(manufacturer); }
  if (location && location !== 'All')    { const c=' AND location=?';           sql+=c; countSQL+=c; params.push(location); }
  if (ram && ram !== 'All')              { const c=' AND ram=?';                sql+=c; countSQL+=c; params.push(ram); }

  return { sql, countSQL, params, page: Number(page), limit: Number(limit) };
}

// ── Assets API ────────────────────────────────────────────────
app.get('/api/assets', (req, res) => {
  const { sql, countSQL, params, page, limit } = buildFilterSQL(req.query);
  const total = db.prepare(countSQL).get(...params).c;
  const rows  = db.prepare(sql + ' ORDER BY id LIMIT ? OFFSET ?').all(...params, limit, (page-1)*limit);
  // attach custom values
  const fields = db.prepare('SELECT * FROM custom_fields ORDER BY sort_order').all();
  const enriched = rows.map(a => {
    const cv = db.prepare('SELECT field_key, value FROM asset_custom_values WHERE asset_id=?').all(a.id);
    const custom = {};
    cv.forEach(r => { custom[r.field_key] = r.value; });
    return { ...a, custom };
  });
  res.json({ assets: enriched, total, page, limit, fields });
});

app.get('/api/assets/:id', (req, res) => {
  const asset = db.prepare('SELECT * FROM assets WHERE id=?').get(req.params.id);
  if (!asset) return res.status(404).json({ error: 'Not found' });
  const cv = db.prepare('SELECT field_key, value FROM asset_custom_values WHERE asset_id=?').all(asset.id);
  const custom = {};
  cv.forEach(r => { custom[r.field_key] = r.value; });
  res.json({ ...asset, custom });
});

app.post('/api/assets', (req, res) => {
  const b = req.body;
  try {
    const result = db.prepare(`INSERT INTO assets
      (company,asset_tag,serial,model,category,status,location,manufacturer,supplier,
       purchase_date,purchase_cost,assign_to,prev_assigned,ram,processor,ssd,hdd,gpu,machine_condition,market_value,notes)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
    ).run(b.company||'OZI-G',b.asset_tag,b.serial,b.model,b.category,b.status||'Ready to Deploy',
      b.location,b.manufacturer,b.supplier,b.purchase_date||null,b.purchase_cost||null,
      b.assign_to,b.prev_assigned,b.ram,b.processor,b.ssd,b.hdd,b.gpu,
      b.machine_condition||'Good',b.market_value||null,b.notes);
    const id = result.lastInsertRowid;
    if (b.custom) saveCustomValues(id, b.custom);
    res.json({ id, message: 'Asset created' });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/assets/:id', (req, res) => {
  const b = req.body;
  try {
    db.prepare(`UPDATE assets SET company=?,asset_tag=?,serial=?,model=?,category=?,status=?,location=?,
      manufacturer=?,supplier=?,purchase_date=?,purchase_cost=?,assign_to=?,prev_assigned=?,
      ram=?,processor=?,ssd=?,hdd=?,gpu=?,machine_condition=?,market_value=?,notes=?,updated_at=datetime('now')
      WHERE id=?`
    ).run(b.company||'OZI-G',b.asset_tag,b.serial,b.model,b.category,b.status,
      b.location,b.manufacturer,b.supplier,b.purchase_date||null,b.purchase_cost||null,
      b.assign_to,b.prev_assigned,b.ram,b.processor,b.ssd,b.hdd,b.gpu,
      b.machine_condition,b.market_value||null,b.notes,req.params.id);
    if (b.custom) saveCustomValues(req.params.id, b.custom);
    res.json({ message: 'Asset updated' });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.delete('/api/assets/:id', (req, res) => {
  db.prepare('DELETE FROM assets WHERE id=?').run(req.params.id);
  res.json({ message: 'Asset deleted' });
});

function saveCustomValues(assetId, custom) {
  const upsert = db.prepare(`INSERT INTO asset_custom_values (asset_id,field_key,value)
    VALUES (?,?,?) ON CONFLICT(asset_id,field_key) DO UPDATE SET value=excluded.value`);
  const run = db.transaction(() => {
    for (const [k, v] of Object.entries(custom)) upsert.run(assetId, k, v || '');
  });
  run();
}

// ── Stats ─────────────────────────────────────────────────────
app.get('/api/stats', (req, res) => {
  const total       = db.prepare('SELECT COUNT(*) as c FROM assets').get().c;
  const byCategory  = db.prepare('SELECT category, COUNT(*) as c FROM assets GROUP BY category').all();
  const byCondition = db.prepare('SELECT machine_condition, COUNT(*) as c FROM assets GROUP BY machine_condition').all();
  const marketValue = db.prepare('SELECT SUM(market_value) as total FROM assets').get().total || 0;
  const purchaseCost= db.prepare('SELECT SUM(purchase_cost) as total FROM assets').get().total || 0;
  res.json({ total, byCategory, byCondition, marketValue, purchaseCost });
});

// ── Filter options (distinct values for dropdowns) ────────────
app.get('/api/filter-options', (req, res) => {
  const distinct = col => db.prepare(`SELECT DISTINCT ${col} FROM assets WHERE ${col} IS NOT NULL AND ${col} != '' ORDER BY ${col}`).all().map(r => r[col]);
  res.json({
    manufacturers: distinct('manufacturer'),
    locations:     distinct('location'),
    rams:          distinct('ram'),
    statuses:      distinct('status'),
  });
});

// ── Custom Fields API ─────────────────────────────────────────
app.get('/api/custom-fields', (req, res) => {
  res.json(db.prepare('SELECT * FROM custom_fields ORDER BY sort_order, id').all());
});

app.post('/api/custom-fields', (req, res) => {
  const { label, field_type = 'text', options = '', required = 0 } = req.body;
  if (!label) return res.status(400).json({ error: 'Label required' });
  const field_key = label.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '') + '_' + Date.now();
  const maxOrder = db.prepare('SELECT MAX(sort_order) as m FROM custom_fields').get().m || 0;
  try {
    const r = db.prepare(`INSERT INTO custom_fields (field_key,label,field_type,options,required,sort_order)
      VALUES (?,?,?,?,?,?)`).run(field_key, label, field_type, options, required ? 1 : 0, maxOrder + 1);
    res.json({ id: r.lastInsertRowid, field_key, label, field_type, options, required });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/custom-fields/:id', (req, res) => {
  const { label, field_type, options, required } = req.body;
  db.prepare(`UPDATE custom_fields SET label=?,field_type=?,options=?,required=? WHERE id=?`)
    .run(label, field_type, options || '', required ? 1 : 0, req.params.id);
  res.json({ message: 'Updated' });
});

app.delete('/api/custom-fields/:id', (req, res) => {
  const field = db.prepare('SELECT field_key FROM custom_fields WHERE id=?').get(req.params.id);
  if (field) {
    db.prepare('DELETE FROM asset_custom_values WHERE field_key=?').run(field.field_key);
    db.prepare('DELETE FROM custom_fields WHERE id=?').run(req.params.id);
  }
  res.json({ message: 'Deleted' });
});

// ── Export ────────────────────────────────────────────────────
function getAllFiltered(query) {
  const { sql, params } = buildFilterSQL({ ...query, limit: 99999, page: 1 });
  return db.prepare(sql + ' ORDER BY id').all(...params);
}

// Export CSV
app.get('/api/export/csv', (req, res) => {
  const rows = getAllFiltered(req.query);
  const fields = db.prepare('SELECT * FROM custom_fields ORDER BY sort_order').all();
  const headers = ['Asset Tag','Serial','Model','Category','Status','Location','Manufacturer',
    'Supplier','Purchase Date','Purchase Cost','Assign To','Prev Assigned','RAM','Processor',
    'SSD','HDD','GPU','Condition','Market Value','Notes',
    ...fields.map(f => f.label)];
  const esc = v => `"${String(v||'').replace(/"/g,'""')}"`;
  const lines = [headers.map(esc).join(',')];
  for (const a of rows) {
    const cv = {};
    db.prepare('SELECT field_key,value FROM asset_custom_values WHERE asset_id=?').all(a.id)
      .forEach(r => { cv[r.field_key] = r.value; });
    lines.push([a.asset_tag,a.serial,a.model,a.category,a.status,a.location,a.manufacturer,
      a.supplier,a.purchase_date,a.purchase_cost,a.assign_to,a.prev_assigned,a.ram,a.processor,
      a.ssd,a.hdd,a.gpu,a.machine_condition,a.market_value,a.notes,
      ...fields.map(f => cv[f.field_key] || '')
    ].map(esc).join(','));
  }
  res.setHeader('Content-Disposition', `attachment; filename="ozi-assets-${Date.now()}.csv"`);
  res.setHeader('Content-Type', 'text/csv');
  res.send(lines.join('\r\n'));
});

// Export Excel
app.get('/api/export/excel', (req, res) => {
  const rows = getAllFiltered(req.query);
  const fields = db.prepare('SELECT * FROM custom_fields ORDER BY sort_order').all();
  const headers = ['Asset Tag','Serial','Model','Category','Status','Location','Manufacturer',
    'Supplier','Purchase Date','Purchase Cost','Assign To','Prev Assigned','RAM','Processor',
    'SSD','HDD','GPU','Condition','Market Value','Notes',
    ...fields.map(f => f.label)];
  const data = [headers];
  for (const a of rows) {
    const cv = {};
    db.prepare('SELECT field_key,value FROM asset_custom_values WHERE asset_id=?').all(a.id)
      .forEach(r => { cv[r.field_key] = r.value; });
    data.push([a.asset_tag,a.serial,a.model,a.category,a.status,a.location,a.manufacturer,
      a.supplier,a.purchase_date||'',a.purchase_cost||'',a.assign_to,a.prev_assigned,a.ram,
      a.processor,a.ssd,a.hdd,a.gpu,a.machine_condition,a.market_value||'',a.notes||'',
      ...fields.map(f => cv[f.field_key] || '')
    ]);
  }
  const buffer = xlsx.build([{ name: 'Assets', data }]);
  res.setHeader('Content-Disposition', `attachment; filename="ozi-assets-${Date.now()}.xlsx"`);
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.send(buffer);
});

// Export PDF (HTML → print-ready page served as text/html with print styles)
app.get('/api/export/pdf', (req, res) => {
  const rows = getAllFiltered(req.query);
  const fields = db.prepare('SELECT * FROM custom_fields ORDER BY sort_order').all();
  const now = new Date().toLocaleString();
  const esc = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

  const trs = rows.map(a => {
    const cv = {};
    db.prepare('SELECT field_key,value FROM asset_custom_values WHERE asset_id=?').all(a.id)
      .forEach(r => { cv[r.field_key] = r.value; });
    return `<tr>
      <td>${esc(a.asset_tag)}</td><td>${esc(a.model)}</td><td>${esc(a.category)}</td>
      <td>${esc(a.manufacturer)}</td><td>${esc(a.assign_to)}</td><td>${esc(a.ram)}</td>
      <td>${esc(a.gpu)}</td><td>${esc(a.machine_condition)}</td>
      <td>${a.market_value ? 'PKR '+Number(a.market_value).toLocaleString() : ''}</td>
      ${fields.map(f=>`<td>${esc(cv[f.field_key]||'')}</td>`).join('')}
    </tr>`;
  }).join('');

  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8">
  <title>OZI-G Asset Report</title>
  <style>
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:Arial,sans-serif;font-size:10px;color:#111;padding:16px}
    h1{font-size:16px;margin-bottom:2px}
    .meta{font-size:10px;color:#555;margin-bottom:12px}
    table{width:100%;border-collapse:collapse;font-size:9px}
    th{background:#185FA5;color:#fff;padding:5px 6px;text-align:left;white-space:nowrap}
    td{padding:4px 6px;border-bottom:0.5px solid #ddd;vertical-align:top}
    tr:nth-child(even) td{background:#f5f7fa}
    .footer{margin-top:12px;font-size:9px;color:#888;text-align:right}
    @media print{
      @page{margin:10mm;size:A4 landscape}
      body{padding:0}
    }
  </style>
  </head><body>
  <h1>OZI-G IT Asset Inventory Report</h1>
  <div class="meta">Generated: ${now} &nbsp;·&nbsp; Total records: ${rows.length}</div>
  <table>
    <thead><tr>
      <th>Asset Tag</th><th>Model</th><th>Category</th><th>Manufacturer</th>
      <th>Assigned To</th><th>RAM</th><th>GPU</th><th>Condition</th><th>Market Value</th>
      ${fields.map(f=>`<th>${esc(f.label)}</th>`).join('')}
    </tr></thead>
    <tbody>${trs}</tbody>
  </table>
  <div class="footer">OZI-G IT Asset Inventory &nbsp;·&nbsp; ${now}</div>
  <script>window.onload=()=>window.print()</script>
  </body></html>`;

  res.setHeader('Content-Type', 'text/html');
  res.send(html);
});

// ── Excel Import ──────────────────────────────────────────────
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (/\.(xlsx|xls|csv)$/i.test(file.originalname)) cb(null, true);
    else cb(new multer.MulterError('LIMIT_UNEXPECTED_FILE', 'Only .xlsx .xls .csv allowed'));
  }
});

const COL_MAP = {
  'asset tag':'asset_tag','assettag':'asset_tag','tag':'asset_tag',
  'serial':'serial','serial number':'serial','serialno':'serial',
  'model':'model','category':'category','type':'category','status':'status',
  'location':'location','manufacturer':'manufacturer','make':'manufacturer','mfr':'manufacturer',
  'supplier':'supplier','vendor':'supplier',
  'purchase date':'purchase_date','purchasedate':'purchase_date','date':'purchase_date',
  'purchase cost':'purchase_cost','purchasecost':'purchase_cost','cost':'purchase_cost','price':'purchase_cost',
  'assign to':'assign_to','assignto':'assign_to','assigned to':'assign_to','assignedto':'assign_to','user':'assign_to',
  'prev assigned':'prev_assigned','previously assigned':'prev_assigned','prevassigned':'prev_assigned',
  'ram':'ram','memory':'ram','processor':'processor','cpu':'processor',
  'ssd':'ssd','hdd':'hdd','hard disk':'hdd','gpu':'gpu','graphic card':'gpu','graphics':'gpu',
  'machine condition':'machine_condition','condition':'machine_condition',
  'market value':'market_value','marketvalue':'market_value','value':'market_value',
  'company':'company','notes':'notes','remarks':'notes',
};

function normalizeKey(k) { return (k||'').toString().toLowerCase().trim().replace(/\s+/g,' '); }

function parseFile(buffer, originalname) {
  if (/\.csv$/i.test(originalname||'')) {
    const text = buffer.toString('utf8');
    const lines = text.split(/\r?\n/).filter(l => l.trim());
    if (!lines.length) return [];
    const splitCSV = line => line.split(',').map(v => v.replace(/^"|"$/g,'').trim());
    const headers = splitCSV(lines[0]);
    return lines.slice(1).map(line => {
      const vals = splitCSV(line);
      const obj = {};
      headers.forEach((h,i) => { obj[h] = vals[i]||''; });
      return obj;
    });
  }
  const sheets = xlsx.parse(buffer);
  if (!sheets.length || !sheets[0].data.length) return [];
  const [headerRow, ...dataRows] = sheets[0].data;
  const headers = headerRow.map(v => v===null||v===undefined ? '' : String(v));
  return dataRows.map(vals => {
    const obj = {};
    headers.forEach((h,i) => { obj[h] = vals[i]===undefined ? '' : vals[i]; });
    return obj;
  });
}

function mapRow(raw) {
  const mapped = {};
  for (const [k,v] of Object.entries(raw)) {
    const dbField = COL_MAP[normalizeKey(k)];
    if (dbField) mapped[dbField] = v===null||v===undefined ? '' : String(v).trim();
  }
  return mapped;
}

app.post('/api/import/preview', (req, res) => {
  upload.single('file')(req, res, err => {
    if (err) return res.status(400).json({ error: err.message });
    try {
      if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
      const rows = parseFile(req.file.buffer, req.file.originalname);
      if (!rows.length) return res.status(400).json({ error: 'File empty or unreadable' });
      const mapped = rows.map(mapRow);
      const valid = mapped.filter(r => r.asset_tag);
      const skipped = mapped.length - valid.length;
      const existing = new Set(db.prepare('SELECT asset_tag FROM assets').all().map(r => r.asset_tag));
      const preview = valid.map(r => ({ ...r, _exists: existing.has(r.asset_tag) }));
      res.json({ total: rows.length, valid: valid.length, skipped, preview });
    } catch (e) { res.status(400).json({ error: e.message }); }
  });
});

app.post('/api/import/commit', express.json({ limit: '5mb' }), (req, res) => {
  const { rows, overwrite } = req.body;
  if (!Array.isArray(rows)||!rows.length) return res.status(400).json({ error: 'No rows' });
  const insert = db.prepare(`INSERT INTO assets
    (company,asset_tag,serial,model,category,status,location,manufacturer,supplier,
     purchase_date,purchase_cost,assign_to,prev_assigned,ram,processor,ssd,hdd,gpu,machine_condition,market_value,notes)
    VALUES (@company,@asset_tag,@serial,@model,@category,@status,@location,@manufacturer,@supplier,
     @purchase_date,@purchase_cost,@assign_to,@prev_assigned,@ram,@processor,@ssd,@hdd,@gpu,@machine_condition,@market_value,@notes)`);
  const update = db.prepare(`UPDATE assets SET company=@company,serial=@serial,model=@model,category=@category,
    status=@status,location=@location,manufacturer=@manufacturer,supplier=@supplier,purchase_date=@purchase_date,
    purchase_cost=@purchase_cost,assign_to=@assign_to,prev_assigned=@prev_assigned,ram=@ram,processor=@processor,
    ssd=@ssd,hdd=@hdd,gpu=@gpu,machine_condition=@machine_condition,market_value=@market_value,notes=@notes,
    updated_at=datetime('now') WHERE asset_tag=@asset_tag`);
  let inserted=0, updated=0, errors=[];
  const existing = new Set(db.prepare('SELECT asset_tag FROM assets').all().map(r => r.asset_tag));
  db.transaction(() => {
    for (const raw of rows) {
      const r = { company:raw.company||'OZI-G', asset_tag:(raw.asset_tag||'').trim(),
        serial:raw.serial||'', model:raw.model||'', category:raw.category||'Desktop',
        status:raw.status||'Ready to Deploy', location:raw.location||'',
        manufacturer:raw.manufacturer||'', supplier:raw.supplier||'',
        purchase_date:raw.purchase_date||null, purchase_cost:raw.purchase_cost?parseFloat(raw.purchase_cost)||null:null,
        assign_to:raw.assign_to||'', prev_assigned:raw.prev_assigned||'',
        ram:raw.ram||'', processor:raw.processor||'', ssd:raw.ssd||'', hdd:raw.hdd||'', gpu:raw.gpu||'',
        machine_condition:raw.machine_condition||'Good',
        market_value:raw.market_value?parseFloat(raw.market_value)||null:null, notes:raw.notes||'' };
      if (!r.asset_tag) { errors.push('Skipped row with no asset_tag'); continue; }
      try {
        if (existing.has(r.asset_tag)) { if (overwrite) { update.run(r); updated++; } }
        else { insert.run(r); inserted++; }
      } catch(e) { errors.push(`${r.asset_tag}: ${e.message}`); }
    }
  })();
  res.json({ inserted, updated, errors });
});

app.get('/api/import/template', (req, res) => {
  const headers = ['Company','Asset Tag','Serial','Model','Category','Status','Location',
    'Manufacturer','Supplier','Purchase Date','Purchase Cost','Assign To','Prev Assigned',
    'RAM','Processor','SSD','HDD','GPU','Machine Condition','Market Value','Notes'];
  const example = ['OZI-G','DSK-OZIG-XXX','ABC123','Precision T5810','Desktop','Ready to Deploy',
    'OZI Technology (Head Office)','DELL','Z.I Computers','2024-01-15','85000','John Doe','',
    '32GB','Intel Xeon E5-2660 v3','480GB','1TB','NVIDIA GTX 1060 6GB','Good','65000',''];
  const csv = [headers,example].map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\r\n')+'\r\n';
  res.setHeader('Content-Disposition','attachment; filename="ozi-inventory-template.csv"');
  res.setHeader('Content-Type','text/csv');
  res.send(csv);
});

app.listen(PORT, () => console.log(`OZI-G Inventory running on http://localhost:${PORT}`));
