// ── State ─────────────────────────────────────────────────────
let currentPage = 1;
let searchTimer = null;
let customFields = [];
let filterOptions = {};
let editingId = null;
let editingCFId = null;
let importPreviewData = [];

// ── Init ──────────────────────────────────────────────────────
(async () => {
  await loadFilterOptions();
  populateFilterDropdowns();
  showView('dashboard');

  // Export dropdown toggle
  document.getElementById('export-btn').addEventListener('click', e => {
    e.stopPropagation();
    document.getElementById('export-menu').classList.toggle('open');
  });
  document.addEventListener('click', () => document.getElementById('export-menu').classList.remove('open'));

  // Drag & drop
  const dz = document.getElementById('drop-zone');
  dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('drag-over'); });
  dz.addEventListener('dragleave', () => dz.classList.remove('drag-over'));
  dz.addEventListener('drop', e => {
    e.preventDefault(); dz.classList.remove('drag-over');
    if (e.dataTransfer.files[0]) handleFileSelect(e.dataTransfer.files[0]);
  });
})();

// ── Views ─────────────────────────────────────────────────────
function showView(view, category) {
  document.querySelectorAll('[id^="view-"]').forEach(el => el.style.display = 'none');
  document.getElementById('view-' + view).style.display = '';
  document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));

  if (view === 'dashboard') {
    document.querySelector('.nav-item').classList.add('active');
    loadDashboard();
  } else if (view === 'assets') {
    currentPage = 1;
    if (category) document.getElementById('cat-filter').value = category;
    document.getElementById('assets-title').textContent =
      category === 'Desktop' ? 'Desktops' : category === 'Laptop' ? 'Laptops' : 'All Assets';
    loadAssets();
  } else if (view === 'custom-fields') {
    loadCustomFields();
  }
}

function clearFilters() {
  document.getElementById('search').value = '';
  ['cat-filter','cond-filter','status-filter','mfr-filter','loc-filter','ram-filter']
    .forEach(id => document.getElementById(id).value = 'All');
  currentPage = 1;
  loadAssets();
}

function debounceLoad() {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => { currentPage = 1; loadAssets(); }, 300);
}

// ── Filter Options ────────────────────────────────────────────
async function loadFilterOptions() {
  filterOptions = await fetch('/api/filter-options').then(r => r.json());
}

function populateFilterDropdowns() {
  const populate = (id, items) => {
    const sel = document.getElementById(id);
    const cur = sel.value;
    while (sel.options.length > 1) sel.remove(1);
    items.forEach(v => { const o = new Option(v, v); sel.add(o); });
    sel.value = cur;
  };
  populate('status-filter', filterOptions.statuses || []);
  populate('mfr-filter', filterOptions.manufacturers || []);
  populate('loc-filter', filterOptions.locations || []);
  populate('ram-filter', filterOptions.rams || []);
}

function getFilters() {
  return {
    q: document.getElementById('search')?.value || '',
    category: document.getElementById('cat-filter')?.value || 'All',
    condition: document.getElementById('cond-filter')?.value || 'All',
    status: document.getElementById('status-filter')?.value || 'All',
    manufacturer: document.getElementById('mfr-filter')?.value || 'All',
    location: document.getElementById('loc-filter')?.value || 'All',
    ram: document.getElementById('ram-filter')?.value || 'All',
  };
}

// ── Dashboard ─────────────────────────────────────────────────
async function loadDashboard() {
  const [stats, recent] = await Promise.all([
    fetch('/api/stats').then(r => r.json()),
    fetch('/api/assets?limit=6&page=1').then(r => r.json()),
  ]);
  const catMap  = Object.fromEntries(stats.byCategory.map(x => [x.category, x.c]));
  const condMap = Object.fromEntries(stats.byCondition.map(x => [x.machine_condition, x.c]));

  document.getElementById('stats-grid').innerHTML = `
    <div class="stat-card"><div class="stat-label">Total assets</div><div class="stat-val">${stats.total}</div></div>
    <div class="stat-card"><div class="stat-label">Desktops</div><div class="stat-val">${catMap.Desktop||0}</div></div>
    <div class="stat-card"><div class="stat-label">Laptops</div><div class="stat-val">${catMap.Laptop||0}</div></div>
    <div class="stat-card"><div class="stat-label">Market value</div><div class="stat-val" style="font-size:17px">PKR ${Number(stats.marketValue||0).toLocaleString()}</div><div class="stat-sub">current total</div></div>
    <div class="stat-card"><div class="stat-label">Purchase cost</div><div class="stat-val" style="font-size:17px">PKR ${Number(stats.purchaseCost||0).toLocaleString()}</div><div class="stat-sub">recorded</div></div>
    <div class="stat-card"><div class="stat-label">Needs attention</div><div class="stat-val" style="color:var(--red)">${condMap.Poor||0}</div><div class="stat-sub">poor condition</div></div>`;

  const conds = ['Excellent','Good','Poor'];
  const condClr = { Excellent:'#0F6E56', Good:'var(--green)', Poor:'var(--red)' };
  document.getElementById('breakdown-grid').innerHTML = `
    <div class="breakdown-card"><h3>By category</h3>
      ${stats.byCategory.map(x=>`<div class="bar-item"><div class="bar-row"><span>${x.category}</span><span>${x.c}</span></div><div class="bar-bg"><div class="bar-fill" style="width:${Math.round(x.c/stats.total*100)}%"></div></div></div>`).join('')}
    </div>
    <div class="breakdown-card"><h3>By condition</h3>
      ${conds.map(c=>{const n=condMap[c]||0;return`<div class="bar-item"><div class="bar-row"><span style="color:${condClr[c]}">${c}</span><span>${n}</span></div><div class="bar-bg"><div class="bar-fill" style="width:${stats.total?Math.round(n/stats.total*100):0}%;background:${condClr[c]}"></div></div></div>`}).join('')}
    </div>`;

  document.getElementById('recent-table').innerHTML = buildMiniTable(recent.assets);
  document.getElementById('last-updated').textContent = 'Updated ' + new Date().toLocaleTimeString();
}

function buildMiniTable(assets) {
  return `<div class="table-wrap"><table>
    <thead><tr><th>Asset Tag</th><th>Model</th><th>Category</th><th>Assigned To</th><th>Condition</th><th>Market Value</th></tr></thead>
    <tbody>${assets.map(a=>`<tr onclick="showView('assets');setTimeout(()=>openDetail(${a.id}),150)">
      <td style="font-weight:600;color:var(--accent)">${a.asset_tag}</td>
      <td>${a.model||'—'}</td>
      <td><span class="badge badge-${(a.category||'').toLowerCase()}">${a.category}</span></td>
      <td>${a.assign_to||'—'}</td>
      <td><span class="cond-${(a.machine_condition||'good').toLowerCase()}">${a.machine_condition}</span></td>
      <td>${a.market_value?'PKR '+Number(a.market_value).toLocaleString():'—'}</td>
    </tr>`).join('')}</tbody></table></div>`;
}

// ── Assets List ───────────────────────────────────────────────
async function loadAssets() {
  const filters = getFilters();
  const params = new URLSearchParams({ ...filters, page: currentPage, limit: 15 });
  const data = await fetch('/api/assets?' + params).then(r => r.json());
  customFields = data.fields || [];

  // Build table header
  const stdCols = ['Asset Tag','Category','Model','Manufacturer','Assigned To','RAM','GPU','Condition','Market Value'];
  const cfCols  = customFields.map(f => f.label);
  document.getElementById('table-head').innerHTML =
    [...stdCols, ...cfCols, 'Actions'].map(c => `<th>${c}</th>`).join('');

  document.getElementById('asset-tbody').innerHTML = data.assets.length
    ? data.assets.map(a => `
      <tr onclick="openDetail(${a.id})">
        <td style="font-weight:600;color:var(--accent)">${a.asset_tag}</td>
        <td><span class="badge badge-${(a.category||'').toLowerCase()}">${a.category}</span></td>
        <td>${a.model||'—'}</td>
        <td>${a.manufacturer||'—'}</td>
        <td>${a.assign_to||'—'}</td>
        <td>${a.ram||'—'}</td>
        <td>${a.gpu||'—'}</td>
        <td><span class="cond-${(a.machine_condition||'good').toLowerCase()}">${a.machine_condition||'—'}</span></td>
        <td>${a.market_value?'PKR '+Number(a.market_value).toLocaleString():'—'}</td>
        ${customFields.map(f=>`<td>${(a.custom&&a.custom[f.field_key])||'—'}</td>`).join('')}
        <td onclick="event.stopPropagation()">
          <button class="btn btn-sm" onclick="openEdit(${a.id})">Edit</button>
          <button class="btn btn-sm btn-danger" onclick="deleteAsset(${a.id},'${a.asset_tag}')">Del</button>
        </td>
      </tr>`).join('')
    : '<tr><td colspan="20" style="text-align:center;padding:2rem;color:var(--muted)">No assets found.</td></tr>';

  const total = data.total, totalPages = Math.ceil(total/15)||1;
  document.getElementById('pagination').innerHTML = `
    <span class="muted">Showing ${Math.min((currentPage-1)*15+1,total)}–${Math.min(currentPage*15,total)} of ${total}</span>
    <div class="pag-btns">
      <button class="btn btn-sm" onclick="changePage(-1)" ${currentPage<=1?'disabled':''}>← Prev</button>
      <button class="btn btn-sm" onclick="changePage(1)" ${currentPage>=totalPages?'disabled':''}>Next →</button>
    </div>`;
}

function changePage(d) { currentPage += d; loadAssets(); }

// ── Export ────────────────────────────────────────────────────
function exportData(type) {
  const filters = getFilters();
  const params = new URLSearchParams(filters);
  if (type === 'pdf') {
    window.open('/api/export/pdf?' + params, '_blank');
  } else {
    const a = document.createElement('a');
    a.href = '/api/export/' + type + '?' + params;
    a.click();
  }
  document.getElementById('export-menu').classList.remove('open');
}

// ── Detail Modal ──────────────────────────────────────────────
async function openDetail(id) {
  const a = await fetch('/api/assets/'+id).then(r=>r.json());
  const cfs = await fetch('/api/custom-fields').then(r=>r.json());
  document.getElementById('modal-title').textContent = a.asset_tag + ' — ' + (a.model||'');

  const cfSection = cfs.length ? `
    <div class="detail-section">
      <h3>Custom Fields</h3>
      <div class="detail-grid">
        ${cfs.map(f=>`<div><div class="detail-label">${f.label}</div><div class="detail-val">${(a.custom&&a.custom[f.field_key])||'—'}</div></div>`).join('')}
      </div>
    </div>` : '';

  document.getElementById('modal-body').innerHTML = `
    <div class="detail-section"><h3>Identity</h3><div class="detail-grid">
      <div><div class="detail-label">Asset Tag</div><div class="detail-val">${a.asset_tag}</div></div>
      <div><div class="detail-label">Serial</div><div class="detail-val">${a.serial||'—'}</div></div>
      <div><div class="detail-label">Model</div><div class="detail-val">${a.model||'—'}</div></div>
      <div><div class="detail-label">Manufacturer</div><div class="detail-val">${a.manufacturer||'—'}</div></div>
      <div><div class="detail-label">Category</div><div class="detail-val">${a.category||'—'}</div></div>
      <div><div class="detail-label">Status</div><div class="detail-val">${a.status||'—'}</div></div>
    </div></div>
    <div class="detail-section"><h3>Assignment</h3><div class="detail-grid">
      <div><div class="detail-label">Assigned To</div><div class="detail-val">${a.assign_to||'—'}</div></div>
      <div><div class="detail-label">Previously Assigned</div><div class="detail-val">${a.prev_assigned||'—'}</div></div>
      <div><div class="detail-label">Location</div><div class="detail-val">${a.location||'—'}</div></div>
      <div><div class="detail-label">Supplier</div><div class="detail-val">${a.supplier||'—'}</div></div>
      <div><div class="detail-label">Purchase Date</div><div class="detail-val">${a.purchase_date||'—'}</div></div>
      <div><div class="detail-label">Purchase Cost</div><div class="detail-val">${a.purchase_cost?'PKR '+Number(a.purchase_cost).toLocaleString():'—'}</div></div>
    </div></div>
    <div class="detail-section"><h3>Specifications</h3><div class="detail-grid">
      <div><div class="detail-label">RAM</div><div class="detail-val">${a.ram||'—'}</div></div>
      <div><div class="detail-label">SSD</div><div class="detail-val">${a.ssd||'—'}</div></div>
      <div><div class="detail-label">HDD</div><div class="detail-val">${a.hdd||'—'}</div></div>
      <div><div class="detail-label">GPU</div><div class="detail-val">${a.gpu||'—'}</div></div>
      <div style="grid-column:1/-1"><div class="detail-label">Processor</div><div class="detail-val">${a.processor||'—'}</div></div>
    </div></div>
    ${cfSection}
    ${a.notes?`<div class="detail-section"><h3>Notes</h3><p style="font-size:13px;color:var(--muted)">${a.notes}</p></div>`:''}
    <div class="market-banner">
      <div><div class="label">Condition</div><div style="font-weight:600;margin-top:2px" class="cond-${(a.machine_condition||'good').toLowerCase()}">${a.machine_condition||'—'}</div></div>
      <div style="text-align:right"><div class="label">Market Value</div><div class="value">${a.market_value?'PKR '+Number(a.market_value).toLocaleString():'N/A'}</div></div>
    </div>
    <div class="modal-actions">
      <button class="btn btn-danger" onclick="deleteAsset(${a.id},'${a.asset_tag}')">Delete</button>
      <button class="btn" onclick="openEdit(${a.id})">Edit</button>
    </div>`;
  showModal('modal-overlay');
}

// ── Add / Edit Modal ──────────────────────────────────────────
async function openAddModal() {
  editingId = null;
  customFields = await fetch('/api/custom-fields').then(r=>r.json());
  document.getElementById('modal-title').textContent = 'Add New Asset';
  document.getElementById('modal-body').innerHTML = buildForm({});
  showModal('modal-overlay');
}

async function openEdit(id) {
  editingId = id;
  const [a, cfs] = await Promise.all([
    fetch('/api/assets/'+id).then(r=>r.json()),
    fetch('/api/custom-fields').then(r=>r.json()),
  ]);
  customFields = cfs;
  document.getElementById('modal-title').textContent = 'Edit: ' + a.asset_tag;
  document.getElementById('modal-body').innerHTML = buildForm(a);
  showModal('modal-overlay');
}

function buildForm(a) {
  const cv = a.custom || {};
  const cfRows = customFields.map(f => {
    const val = cv[f.field_key] || '';
    let input = '';
    if (f.field_type === 'select') {
      const opts = (f.options||'').split(',').map(o=>o.trim()).filter(Boolean);
      input = `<select id="cf-${f.field_key}"><option value="">— select —</option>${opts.map(o=>`<option ${val===o?'selected':''}>${o}</option>`).join('')}</select>`;
    } else if (f.field_type === 'textarea') {
      input = `<textarea id="cf-${f.field_key}">${val}</textarea>`;
    } else {
      input = `<input id="cf-${f.field_key}" type="${f.field_type}" value="${val}">`;
    }
    return `<div class="form-group"><label>${f.label}${f.required?' *':''}</label>${input}</div>`;
  });

  return `<div class="form-grid">
    <div class="form-section">Identity</div>
    <div class="form-group"><label>Asset Tag *</label><input id="f-asset_tag" value="${a.asset_tag||''}"></div>
    <div class="form-group"><label>Serial</label><input id="f-serial" value="${a.serial||''}"></div>
    <div class="form-group"><label>Model</label><input id="f-model" value="${a.model||''}"></div>
    <div class="form-group"><label>Category</label>
      <select id="f-category"><option ${a.category==='Desktop'?'selected':''}>Desktop</option><option ${a.category==='Laptop'?'selected':''}>Laptop</option></select></div>
    <div class="form-group"><label>Manufacturer</label><input id="f-manufacturer" value="${a.manufacturer||''}"></div>
    <div class="form-group"><label>Supplier</label><input id="f-supplier" value="${a.supplier||''}"></div>
    <div class="form-group"><label>Status</label>
      <select id="f-status">
        ${['Ready to Deploy','In Use','Faulty','Retired'].map(s=>`<option ${a.status===s?'selected':''}>${s}</option>`).join('')}
      </select></div>
    <div class="form-group full"><label>Location</label><input id="f-location" value="${a.location||''}"></div>

    <div class="form-section">Assignment</div>
    <div class="form-group"><label>Assigned To</label><input id="f-assign_to" value="${a.assign_to||''}"></div>
    <div class="form-group"><label>Prev Assigned</label><input id="f-prev_assigned" value="${a.prev_assigned||''}"></div>
    <div class="form-group"><label>Purchase Date</label><input id="f-purchase_date" type="date" value="${a.purchase_date||''}"></div>
    <div class="form-group"><label>Purchase Cost (PKR)</label><input id="f-purchase_cost" type="number" value="${a.purchase_cost||''}"></div>

    <div class="form-section">Specifications</div>
    <div class="form-group"><label>RAM</label><input id="f-ram" value="${a.ram||''}"></div>
    <div class="form-group"><label>SSD</label><input id="f-ssd" value="${a.ssd||''}"></div>
    <div class="form-group"><label>HDD</label><input id="f-hdd" value="${a.hdd||''}"></div>
    <div class="form-group"><label>GPU</label><input id="f-gpu" value="${a.gpu||''}"></div>
    <div class="form-group full"><label>Processor</label><input id="f-processor" value="${a.processor||''}"></div>

    <div class="form-section">Valuation</div>
    <div class="form-group"><label>Condition</label>
      <select id="f-machine_condition">
        ${['Good','Excellent','Poor'].map(c=>`<option ${a.machine_condition===c?'selected':''}>${c}</option>`).join('')}
      </select></div>
    <div class="form-group"><label>Market Value (PKR)</label><input id="f-market_value" type="number" value="${a.market_value||''}"></div>
    <div class="form-group full"><label>Notes</label><textarea id="f-notes">${a.notes||''}</textarea></div>

    ${customFields.length ? `<div class="form-section">Custom Fields</div>${cfRows.join('')}` : ''}
  </div>
  <div class="modal-actions">
    <button class="btn" onclick="document.getElementById('modal-overlay').style.display='none'">Cancel</button>
    <button class="btn btn-primary" onclick="saveAsset()">Save asset</button>
  </div>`;
}

function getFormData() {
  const fields = ['asset_tag','serial','model','category','manufacturer','supplier','status',
    'location','assign_to','prev_assigned','purchase_date','purchase_cost','ram','ssd','hdd',
    'gpu','processor','machine_condition','market_value','notes'];
  const data = {};
  fields.forEach(f => { const el = document.getElementById('f-'+f); if(el) data[f]=el.value.trim(); });
  data.custom = {};
  customFields.forEach(f => {
    const el = document.getElementById('cf-'+f.field_key);
    if (el) data.custom[f.field_key] = el.value.trim();
  });
  return data;
}

async function saveAsset() {
  const data = getFormData();
  if (!data.asset_tag) { alert('Asset tag is required.'); return; }
  const url = editingId ? '/api/assets/'+editingId : '/api/assets';
  const method = editingId ? 'PUT' : 'POST';
  const res = await fetch(url, { method, headers:{'Content-Type':'application/json'}, body: JSON.stringify(data) });
  const json = await res.json();
  if (json.error) { alert('Error: '+json.error); return; }
  document.getElementById('modal-overlay').style.display = 'none';
  await loadFilterOptions();
  populateFilterDropdowns();
  loadAssets();
}

async function deleteAsset(id, tag) {
  if (!confirm(`Delete ${tag}? This cannot be undone.`)) return;
  await fetch('/api/assets/'+id, { method:'DELETE' });
  document.getElementById('modal-overlay').style.display = 'none';
  loadAssets();
}

// ── Custom Fields ─────────────────────────────────────────────
async function loadCustomFields() {
  const fields = await fetch('/api/custom-fields').then(r=>r.json());
  const typeLabels = { text:'Text', number:'Number', date:'Date', select:'Dropdown', textarea:'Long Text' };
  const typeIcons  = { text:'T', number:'#', date:'📅', select:'▾', textarea:'¶' };

  document.getElementById('cf-list').innerHTML = fields.length
    ? fields.map(f => `
      <div class="cf-card">
        <div class="cf-icon">${typeIcons[f.field_type]||'T'}</div>
        <div class="cf-info">
          <div class="cf-label">${f.label}${f.required?' <span style="color:var(--red);font-size:11px">required</span>':''}</div>
          <div class="cf-meta">Type: ${typeLabels[f.field_type]||f.field_type}${f.options?' · Options: '+f.options:''}</div>
        </div>
        <button class="btn btn-sm" onclick="openCFModal(${f.id})">Edit</button>
        <button class="btn btn-sm btn-danger" onclick="deleteCF(${f.id},'${f.label}')">Delete</button>
      </div>`).join('')
    : `<div class="cf-empty">
        <div style="font-size:32px;margin-bottom:8px">📋</div>
        No custom fields yet. Add one to track extra info like warranty, purchase order, or department.
      </div>`;
}

function openCFModal(id) {
  editingCFId = id || null;
  document.getElementById('cf-modal-title').textContent = id ? 'Edit Custom Field' : 'Add Custom Field';
  document.getElementById('cf-label').value = '';
  document.getElementById('cf-type').value = 'text';
  document.getElementById('cf-options').value = '';
  document.getElementById('cf-required').checked = false;
  document.getElementById('cf-options-group').style.display = 'none';

  if (id) {
    fetch('/api/custom-fields').then(r=>r.json()).then(fields => {
      const f = fields.find(x => x.id === id);
      if (!f) return;
      document.getElementById('cf-label').value = f.label;
      document.getElementById('cf-type').value = f.field_type;
      document.getElementById('cf-options').value = f.options || '';
      document.getElementById('cf-required').checked = !!f.required;
      document.getElementById('cf-options-group').style.display = f.field_type === 'select' ? '' : 'none';
    });
  }
  showModal('cf-overlay');
}

function toggleCFOptions() {
  document.getElementById('cf-options-group').style.display =
    document.getElementById('cf-type').value === 'select' ? '' : 'none';
}

async function saveCF() {
  const label    = document.getElementById('cf-label').value.trim();
  const field_type = document.getElementById('cf-type').value;
  const options  = document.getElementById('cf-options').value.trim();
  const required = document.getElementById('cf-required').checked;
  if (!label) { alert('Label is required.'); return; }

  const url    = editingCFId ? '/api/custom-fields/'+editingCFId : '/api/custom-fields';
  const method = editingCFId ? 'PUT' : 'POST';
  const res = await fetch(url, { method, headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ label, field_type, options, required }) });
  const json = await res.json();
  if (json.error) { alert('Error: '+json.error); return; }
  document.getElementById('cf-overlay').style.display = 'none';
  loadCustomFields();
}

async function deleteCF(id, label) {
  if (!confirm(`Delete custom field "${label}"?\nAll values stored for this field will also be deleted.`)) return;
  await fetch('/api/custom-fields/'+id, { method:'DELETE' });
  loadCustomFields();
}

function closeCFModal(e) {
  if (e.target === document.getElementById('cf-overlay'))
    document.getElementById('cf-overlay').style.display = 'none';
}

// ── Import ────────────────────────────────────────────────────
function openImportModal() {
  resetImport();
  showModal('import-overlay');
}

function closeImportModal(e) {
  if (e.target === document.getElementById('import-overlay'))
    document.getElementById('import-overlay').style.display = 'none';
}

function resetImport() {
  importPreviewData = [];
  document.getElementById('file-input').value = '';
  document.getElementById('file-status').textContent = '';
  document.getElementById('import-step-1').style.display = '';
  document.getElementById('import-step-2').style.display = 'none';
  document.getElementById('import-step-3').style.display = 'none';
}

async function handleFileSelect(file) {
  if (!file) return;
  const status = document.getElementById('file-status');
  status.textContent = `📄 ${file.name} (${(file.size/1024).toFixed(1)} KB) — uploading…`;
  const fd = new FormData();
  fd.append('file', file);
  try {
    const data = await fetch('/api/import/preview', { method:'POST', body:fd }).then(r=>r.json());
    if (data.error) { status.textContent = '❌ '+data.error; return; }
    status.textContent = '';
    showPreview(data);
  } catch (e) { status.textContent = '❌ Upload failed: '+e.message; }
}

function showPreview(data) {
  importPreviewData = data.preview;
  const newR = data.preview.filter(r=>!r._exists).length;
  const exR  = data.preview.filter(r=>r._exists).length;
  document.getElementById('import-summary').innerHTML = `
    <div class="sum-chip"><div class="num">${data.total}</div><div class="lbl">In file</div></div>
    <div class="sum-chip green"><div class="num">${newR}</div><div class="lbl">New</div></div>
    <div class="sum-chip amber"><div class="num">${exR}</div><div class="lbl">Exists</div></div>
    <div class="sum-chip red"><div class="num">${data.skipped}</div><div class="lbl">Skipped</div></div>`;
  const cols = ['asset_tag','model','category','manufacturer','assign_to','ram','machine_condition','market_value'];
  const lbls = ['Asset Tag','Model','Category','Manufacturer','Assigned To','RAM','Condition','Value'];
  document.getElementById('preview-wrap').innerHTML = `<table>
    <thead><tr><th>Status</th>${lbls.map(l=>`<th>${l}</th>`).join('')}</tr></thead>
    <tbody>${data.preview.map(r=>`<tr class="${r._exists?'row-exists':'row-new'}">
      <td><span class="${r._exists?'tag-exists':'tag-new'}">${r._exists?'EXISTS':'NEW'}</span></td>
      ${cols.map(c=>`<td>${r[c]||'—'}</td>`).join('')}
    </tr>`).join('')}</tbody></table>`;
  document.getElementById('import-step-1').style.display = 'none';
  document.getElementById('import-step-2').style.display = '';
}

async function commitImport() {
  const overwrite = document.getElementById('overwrite-chk').checked;
  const btn = document.getElementById('commit-btn');
  btn.disabled = true; btn.textContent = 'Importing…';
  try {
    const data = await fetch('/api/import/commit', { method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ rows: importPreviewData, overwrite }) }).then(r=>r.json());
    document.getElementById('import-result').innerHTML = `
      <div class="result-box ${data.errors?.length?'partial':'success'}">
        <h3>${data.errors?.length?'⚠️ Done with issues':'✅ Import successful!'}</h3>
        <p><strong>${data.inserted}</strong> added &nbsp;·&nbsp; <strong>${data.updated}</strong> updated</p>
        ${data.errors?.length?`<p style="color:var(--red);margin-top:8px">${data.errors.join('<br>')}</p>`:''}
      </div>`;
    document.getElementById('import-step-2').style.display = 'none';
    document.getElementById('import-step-3').style.display = '';
  } catch(e) { alert('Import failed: '+e.message); }
  finally { btn.disabled=false; btn.textContent='Import assets'; }
}

// ── Utilities ─────────────────────────────────────────────────
function showModal(id) { document.getElementById(id).style.display='flex'; }
function closeModal(e) {
  if (e.target===document.getElementById('modal-overlay'))
    document.getElementById('modal-overlay').style.display='none';
}
