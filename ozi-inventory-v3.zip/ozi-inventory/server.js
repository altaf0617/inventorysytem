const express = require('express');
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const xlsx = require('node-xlsx');

const app = express();
const PORT = process.env.PORT || 3000;

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

const db = new Database(path.join(DATA_DIR, 'inventory.db'));

// ── Schema ────────────────────────────────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company TEXT DEFAULT 'OZI-G',
    asset_tag TEXT UNIQUE NOT NULL,
    serial TEXT,
    model TEXT,
    category TEXT,
    status TEXT DEFAULT 'Ready to Deploy',
    location TEXT,
    manufacturer TEXT,
    supplier TEXT,
    purchase_date TEXT,
    purchase_cost REAL,
    assign_to TEXT,
    prev_assigned TEXT,
    ram TEXT,
    processor TEXT,
    ssd TEXT,
    hdd TEXT,
    gpu TEXT,
    machine_condition TEXT DEFAULT 'Good',
    market_value REAL,
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS custom_fields (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    field_key  TEXT UNIQUE NOT NULL,
    label      TEXT NOT NULL,
    field_type TEXT NOT NULL DEFAULT 'text',
    options    TEXT,
    required   INTEGER DEFAULT 0,
    sort_order INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS asset_custom_values (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id   INTEGER NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
    field_key  TEXT NOT NULL,
    value      TEXT,
    UNIQUE(asset_id, field_key)
  );
`);

// ── Seed ─────────────────────────────────────────────────────
const count = db.prepare('SELECT COUNT(*) as c FROM assets').get();
if (count.c === 0) {
  const ins = db.prepare(`INSERT OR IGNORE INTO assets
    (company,asset_tag,serial,model,category,status,location,manufacturer,supplier,
     purchase_date,purchase_cost,assign_to,prev_assigned,ram,processor,ssd,hdd,gpu,machine_condition,market_value)
    VALUES (@company,@asset_tag,@serial,@model,@category,@status,@location,@manufacturer,@supplier,
     @purchase_date,@purchase_cost,@assign_to,@prev_assigned,@ram,@processor,@ssd,@hdd,@gpu,@machine_condition,@market_value)`);
  const seed = db.transaction(rows => { for (const r of rows) ins.run(r); });
  seed([
    {company:'OZI-G',asset_tag:'DSK-OZIG-001',serial:'5JYRF2S',model:'Precision T3600',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'FREE',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'',ram:'16GB',processor:'Quad Core E5-1620 3.60GHz',ssd:'480GB',hdd:'',gpu:'NVIDIA GeForce GTX 1060 6GB',machine_condition:'Good',market_value:45000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-002',serial:'CP51CD2',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Z.I Computers',purchase_date:'2020-11-09',purchase_cost:138000,assign_to:'Aftab Ali',prev_assigned:'OZI-G',ram:'32GB',processor:'Intel Xeon E5 1650 V3 @ 3.50GHz',ssd:'480GB',hdd:'1TB',gpu:'Radeon RX 580 8GB',machine_condition:'Good',market_value:70000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-003',serial:'HC1BDH2',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Dabeer Irfan',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'',ram:'32GB',processor:'Intel Xeon E5-2660 v3 @ 2.60GHz',ssd:'240GB',hdd:'2TB',gpu:'NVIDIA GTX 1050 Ti 4GB',machine_condition:'Good',market_value:65000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-004',serial:'59R0KB2',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Z.I Computers',purchase_date:'2022-09-19',purchase_cost:77000,assign_to:'Daniyal Jawad',prev_assigned:'OZI-G',ram:'32GB',processor:'Intel Xeon E5-2660 V3 @ 2.60GHz',ssd:'480GB',hdd:'1TB',gpu:'',machine_condition:'Good',market_value:65000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-005',serial:'37Y7XK2',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Z.I Computers',purchase_date:'2022-09-19',purchase_cost:81000,assign_to:'Muhammad Faiq',prev_assigned:'OZI-G',ram:'32GB',processor:'Intel Xeon E5-2658 V3 @ 2.20GHz',ssd:'480GB',hdd:'1TB, 1TB',gpu:'AMD RX 580 Series',machine_condition:'Good',market_value:65000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-006',serial:'5VZYF2S',model:'Precision T7600',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'FREE / In IT Inventory',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'',ram:'32GB',processor:'Octa Core E5-2660 @ 2.20GHz x2',ssd:'480GB',hdd:'',gpu:'NVIDIA GeForce GTX 1060 6GB',machine_condition:'Good',market_value:90000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-007',serial:'J3TBC2S',model:'Precision T5500',category:'Desktop',status:'Faulty',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'',purchase_date:null,purchase_cost:null,assign_to:'FAULTY',prev_assigned:'',ram:'16GB',processor:'Intel Xeon E5645 Hexa Core 2.4GHz',ssd:'',hdd:'',gpu:'',machine_condition:'Poor',market_value:30000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-008',serial:'6LVCJB2',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Halta Enterprises',purchase_date:'2022-09-19',purchase_cost:82000,assign_to:'Muhammad Usama Irshad',prev_assigned:'Playcraft',ram:'32GB',processor:'Intel Xeon 2670 v3',ssd:'512GB',hdd:'500GB',gpu:'NVIDIA GTX 1060 3GB',machine_condition:'Good',market_value:60000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-010',serial:'R8PG59X',model:'Thinkstation D20',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'Lenovo',supplier:'FREE / In IT Inventory',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'AppWing',ram:'16GB',processor:'Intel Xeon X5690 / 3.33GHz (2 processors)',ssd:'256GB',hdd:'1TB',gpu:'NVIDIA GeForce GTX 1060 6GB',machine_condition:'Good',market_value:70000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-011',serial:'FLQ0ZY1',model:'Precision T3600',category:'Desktop',status:'Ready to Deploy',location:'OZI-LABS',manufacturer:'DELL',supplier:'OUT OF OFFICE',purchase_date:null,purchase_cost:null,assign_to:'OZI-LABS',prev_assigned:'',ram:'16GB',processor:'Intel Xeon E5-1660 @ 3.30GHz',ssd:'256GB',hdd:'1TB',gpu:'NVIDIA GeForce GTX 1050 Ti',machine_condition:'Good',market_value:60000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-012',serial:'8C6WJS1',model:'Precision T5500',category:'Desktop',status:'Ready to Deploy',location:'OZI-LABS',manufacturer:'DELL',supplier:'OUT OF OFFICE',purchase_date:null,purchase_cost:null,assign_to:'OZI-LABS',prev_assigned:'',ram:'32GB',processor:'Intel Xeon X5675 @ 3.07GHz',ssd:'256GB',hdd:'1TB',gpu:'NVIDIA GeForce GTX 1050 4GB TI',machine_condition:'Good',market_value:55000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-013',serial:'2UA8112514',model:'Z440',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'HP',supplier:'Game & Greeks',purchase_date:'2022-09-19',purchase_cost:128500,assign_to:'Ex-Nauman Aslam',prev_assigned:'OZI-G',ram:'32GB',processor:'Intel Xeon E5-2670 v3 @ 2.30GHz',ssd:'512GB',hdd:'2TB',gpu:'NVIDIA GeForce GTX 1060 3GB (Dual Fan)',machine_condition:'Good',market_value:70000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-014',serial:'INVALID',model:'Asus Gaming Board',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'Asus',supplier:"Gamer's Bay",purchase_date:'2022-08-03',purchase_cost:585000,assign_to:'Rendering Machine / Local VM',prev_assigned:'AppWing',ram:'64GB',processor:'Intel Core i9-11900k 11th Gen',ssd:'NVMe M.2 1TB',hdd:'2TB',gpu:'NVIDIA RTX 3060 12GB',machine_condition:'Excellent',market_value:385000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-015',serial:'F7GT182',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Salar Jahan Wallah',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'',ram:'32GB',processor:'Intel Xeon E5-2673 v3 @ 2.40GHz',ssd:'500NVMe',hdd:'1TB',gpu:'Zotac GTX 1060 3GB',machine_condition:'Good',market_value:60000},
    {company:'OZI-G',asset_tag:'LPT-OZIG-001',serial:'PF2PJ4PP',model:'82FG',category:'Laptop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'Lenovo',supplier:'Century Laptops',purchase_date:'2022-09-19',purchase_cost:151000,assign_to:'Ghulam Ahmad',prev_assigned:'OZI-G',ram:'16GB',processor:'Intel Core i7 11th Generation',ssd:'512GB',hdd:'',gpu:'NVIDIA MX 450',machine_condition:'Good',market_value:80000},
    {company:'OZI-G',asset_tag:'LPT-OZIG-002',serial:'C02W81Z0HTDF',model:'MacBook Pro 2017 15-inch',category:'Laptop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'Apple',supplier:'Laptop World',purchase_date:'2017-01-01',purchase_cost:280000,assign_to:'Haseeb Ahmed',prev_assigned:'OZI-G',ram:'16GB',processor:'Intel Core i7 @ 3.10GHz',ssd:'1TB',hdd:'',gpu:'4GB',machine_condition:'Good',market_value:185000},
    {company:'OZI-G',asset_tag:'LPT-OZIG-004',serial:'PF07MRV2',model:'80 E5',category:'Laptop',status:'Ready to Deploy',location:'OZI-LABS',manufacturer:'Lenovo',supplier:'OUT OF OFFICE',purchase_date:null,purchase_cost:null,assign_to:'OZI-LABS',prev_assigned:'',ram:'8GB',processor:'Intel Core i5',ssd:'256GB',hdd:'500GB',gpu:'AMD Radeon R5 M330',machine_condition:'Good',market_value:null},
    {company:'OZI-G',asset_tag:'LPT-OZIG-005',serial:'1RPQPH3',model:'Inspiron 3501',category:'Laptop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Century Laptops',purchase_date:'2022-01-12',purchase_cost:170000,assign_to:'Abdul Saboor',prev_assigned:'OZI-Theta',ram:'16GB',processor:'Intel Core i7-1165G7 @ 2.80GHz',ssd:'512GB',hdd:'',gpu:'NVIDIA GeForce MX330',machine_condition:'Good',market_value:110000},
    {company:'OZI-G',asset_tag:'LPT-OZIG-006',serial:'111X3G3',model:'Inspiron 3501',category:'Laptop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Century Laptops',purchase_date:null,purchase_cost:170000,assign_to:'Salman Sheikh',prev_assigned:'OZI-G',ram:'16GB',processor:'Intel Core i7 11th Generation',ssd:'512GB',hdd:'',gpu:'MX330 2GB',machine_condition:'Good',market_value:120000},
    {company:'OZI-G',asset_tag:'LPT-OZIG-008',serial:'5CG424DTW3',model:'ProBook 350 G1',category:'Laptop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'HP',supplier:'Hamza / Sheikh Sb',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'',ram:'8GB',processor:'Intel Core i5-4200U @ 1.60GHz',ssd:'256GB',hdd:'500GB',gpu:'AMD HD 8600MS 2GB',machine_condition:'Good',market_value:45000},
  ]);
}

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── Helper: build filter SQL ──────────────────────────────────
function buildFilterSQL(query) {
  const { q, category, condition, status, manufacturer, location, ram, page = 1, limit = 15 } = query;
  let sql = 'SELECT * FROM assets WHERE 1=1';
  let countSQL = 'SELECT COUNT(*) as c FROM assets WHERE 1=1';
  const params = [];

  if (q) {
    const clause = ' AND (asset_tag LIKE ? OR model LIKE ? OR assign_to LIKE ? OR serial LIKE ? OR manufacturer LIKE ? OR gpu LIKE ? OR processor LIKE ? OR location LIKE ?)';
    sql += clause; countSQL += clause;
    const like = `%${q}%`;
    params.push(like,like,like,like,like,like,like,like);
  }
  if (category && category !== 'All')    { const c=' AND category=?';          sql+=c; countSQL+=c; params.push(category); }
  if (condition && condition !== 'All')  { const c=' AND machine_condition=?';  sql+=c; countSQL+=c; params.push(condition); }
  if (status && status !== 'All')        { const c=' AND status=?';             sql+=c; countSQL+=c; params.push(status); }
  if (manufacturer && manufacturer !== 'All') { const c=' AND manufacturer=?'; sql+=c; countSQL+=c; params.push(manufacturer); }
  if (location && location !== 'All')    { const c=' AND location=?';           sql+=c; countSQL+=c; params.push(location); }
  if (ram && ram !== 'All')              { const c=' AND ram=?';                sql+=c; countSQL+=c; params.push(ram); }

  return { sql, countSQL, params, page: Number(page), limit: Number(limit) };
}

// ── Assets API ────────────────────────────────────────────────
app.get('/api/assets', (req, res) => {
  const { sql, countSQL, params, page, limit } = buildFilterSQL(req.query);
  const total = db.prepare(countSQL).get(...params).c;
  const rows  = db.prepare(sql + ' ORDER BY id LIMIT ? OFFSET ?').all(...params, limit, (page-1)*limit);
  // attach custom values
  const fields = db.prepare('SELECT * FROM custom_fields ORDER BY sort_order').all();
  const enriched = rows.map(a => {
    const cv = db.prepare('SELECT field_key, value FROM asset_custom_values WHERE asset_id=?').all(a.id);
    const custom = {};
    cv.forEach(r => { custom[r.field_key] = r.value; });
    return { ...a, custom };
  });
  res.json({ assets: enriched, total, page, limit, fields });
});

app.get('/api/assets/:id', (req, res) => {
  const asset = db.prepare('SELECT * FROM assets WHERE id=?').get(req.params.id);
  if (!asset) return res.status(404).json({ error: 'Not found' });
  const cv = db.prepare('SELECT field_key, value FROM asset_custom_values WHERE asset_id=?').all(asset.id);
  const custom = {};
  cv.forEach(r => { custom[r.field_key] = r.value; });
  res.json({ ...asset, custom });
});

app.post('/api/assets', (req, res) => {
  const b = req.body;
  try {
    const result = db.prepare(`INSERT INTO assets
      (company,asset_tag,serial,model,category,status,location,manufacturer,supplier,
       purchase_date,purchase_cost,assign_to,prev_assigned,ram,processor,ssd,hdd,gpu,machine_condition,market_value,notes)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
    ).run(b.company||'OZI-G',b.asset_tag,b.serial,b.model,b.category,b.status||'Ready to Deploy',
      b.location,b.manufacturer,b.supplier,b.purchase_date||null,b.purchase_cost||null,
      b.assign_to,b.prev_assigned,b.ram,b.processor,b.ssd,b.hdd,b.gpu,
      b.machine_condition||'Good',b.market_value||null,b.notes);
    const id = result.lastInsertRowid;
    if (b.custom) saveCustomValues(id, b.custom);
    res.json({ id, message: 'Asset created' });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/assets/:id', (req, res) => {
  const b = req.body;
  try {
    db.prepare(`UPDATE assets SET company=?,asset_tag=?,serial=?,model=?,category=?,status=?,location=?,
      manufacturer=?,supplier=?,purchase_date=?,purchase_cost=?,assign_to=?,prev_assigned=?,
      ram=?,processor=?,ssd=?,hdd=?,gpu=?,machine_condition=?,market_value=?,notes=?,updated_at=datetime('now')
      WHERE id=?`
    ).run(b.company||'OZI-G',b.asset_tag,b.serial,b.model,b.category,b.status,
      b.location,b.manufacturer,b.supplier,b.purchase_date||null,b.purchase_cost||null,
      b.assign_to,b.prev_assigned,b.ram,b.processor,b.ssd,b.hdd,b.gpu,
      b.machine_condition,b.market_value||null,b.notes,req.params.id);
    if (b.custom) saveCustomValues(req.params.id, b.custom);
    res.json({ message: 'Asset updated' });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.delete('/api/assets/:id', (req, res) => {
  db.prepare('DELETE FROM assets WHERE id=?').run(req.params.id);
  res.json({ message: 'Asset deleted' });
});

function saveCustomValues(assetId, custom) {
  const upsert = db.prepare(`INSERT INTO asset_custom_values (asset_id,field_key,value)
    VALUES (?,?,?) ON CONFLICT(asset_id,field_key) DO UPDATE SET value=excluded.value`);
  const run = db.transaction(() => {
    for (const [k, v] of Object.entries(custom)) upsert.run(assetId, k, v || '');
  });
  run();
}

// ── Stats ─────────────────────────────────────────────────────
app.get('/api/stats', (req, res) => {
  const total       = db.prepare('SELECT COUNT(*) as c FROM assets').get().c;
  const byCategory  = db.prepare('SELECT category, COUNT(*) as c FROM assets GROUP BY category').all();
  const byCondition = db.prepare('SELECT machine_condition, COUNT(*) as c FROM assets GROUP BY machine_condition').all();
  const marketValue = db.prepare('SELECT SUM(market_value) as total FROM assets').get().total || 0;
  const purchaseCost= db.prepare('SELECT SUM(purchase_cost) as total FROM assets').get().total || 0;
  res.json({ total, byCategory, byCondition, marketValue, purchaseCost });
});

// ── Filter options (distinct values for dropdowns) ────────────
app.get('/api/filter-options', (req, res) => {
  const distinct = col => db.prepare(`SELECT DISTINCT ${col} FROM assets WHERE ${col} IS NOT NULL AND ${col} != '' ORDER BY ${col}`).all().map(r => r[col]);
  res.json({
    manufacturers: distinct('manufacturer'),
    locations:     distinct('location'),
    rams:          distinct('ram'),
    statuses:      distinct('status'),
  });
});

// ── Custom Fields API ─────────────────────────────────────────
app.get('/api/custom-fields', (req, res) => {
  res.json(db.prepare('SELECT * FROM custom_fields ORDER BY sort_order, id').all());
});

app.post('/api/custom-fields', (req, res) => {
  const { label, field_type = 'text', options = '', required = 0 } = req.body;
  if (!label) return res.status(400).json({ error: 'Label required' });
  const field_key = label.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '') + '_' + Date.now();
  const maxOrder = db.prepare('SELECT MAX(sort_order) as m FROM custom_fields').get().m || 0;
  try {
    const r = db.prepare(`INSERT INTO custom_fields (field_key,label,field_type,options,required,sort_order)
      VALUES (?,?,?,?,?,?)`).run(field_key, label, field_type, options, required ? 1 : 0, maxOrder + 1);
    res.json({ id: r.lastInsertRowid, field_key, label, field_type, options, required });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/custom-fields/:id', (req, res) => {
  const { label, field_type, options, required } = req.body;
  db.prepare(`UPDATE custom_fields SET label=?,field_type=?,options=?,required=? WHERE id=?`)
    .run(label, field_type, options || '', required ? 1 : 0, req.params.id);
  res.json({ message: 'Updated' });
});

app.delete('/api/custom-fields/:id', (req, res) => {
  const field = db.prepare('SELECT field_key FROM custom_fields WHERE id=?').get(req.params.id);
  if (field) {
    db.prepare('DELETE FROM asset_custom_values WHERE field_key=?').run(field.field_key);
    db.prepare('DELETE FROM custom_fields WHERE id=?').run(req.params.id);
  }
  res.json({ message: 'Deleted' });
});

// ── Export ────────────────────────────────────────────────────
function getAllFiltered(query) {
  const { sql, params } = buildFilterSQL({ ...query, limit: 99999, page: 1 });
  return db.prepare(sql + ' ORDER BY id').all(...params);
}

// Export CSV
app.get('/api/export/csv', (req, res) => {
  const rows = getAllFiltered(req.query);
  const fields = db.prepare('SELECT * FROM custom_fields ORDER BY sort_order').all();
  const headers = ['Asset Tag','Serial','Model','Category','Status','Location','Manufacturer',
    'Supplier','Purchase Date','Purchase Cost','Assign To','Prev Assigned','RAM','Processor',
    'SSD','HDD','GPU','Condition','Market Value','Notes',
    ...fields.map(f => f.label)];
  const esc = v => `"${String(v||'').replace(/"/g,'""')}"`;
  const lines = [headers.map(esc).join(',')];
  for (const a of rows) {
    const cv = {};
    db.prepare('SELECT field_key,value FROM asset_custom_values WHERE asset_id=?').all(a.id)
      .forEach(r => { cv[r.field_key] = r.value; });
    lines.push([a.asset_tag,a.serial,a.model,a.category,a.status,a.location,a.manufacturer,
      a.supplier,a.purchase_date,a.purchase_cost,a.assign_to,a.prev_assigned,a.ram,a.processor,
      a.ssd,a.hdd,a.gpu,a.machine_condition,a.market_value,a.notes,
      ...fields.map(f => cv[f.field_key] || '')
    ].map(esc).join(','));
  }
  res.setHeader('Content-Disposition', `attachment; filename="ozi-assets-${Date.now()}.csv"`);
  res.setHeader('Content-Type', 'text/csv');
  res.send(lines.join('\r\n'));
});

// Export Excel
app.get('/api/export/excel', (req, res) => {
  const rows = getAllFiltered(req.query);
  const fields = db.prepare('SELECT * FROM custom_fields ORDER BY sort_order').all();
  const headers = ['Asset Tag','Serial','Model','Category','Status','Location','Manufacturer',
    'Supplier','Purchase Date','Purchase Cost','Assign To','Prev Assigned','RAM','Processor',
    'SSD','HDD','GPU','Condition','Market Value','Notes',
    ...fields.map(f => f.label)];
  const data = [headers];
  for (const a of rows) {
    const cv = {};
    db.prepare('SELECT field_key,value FROM asset_custom_values WHERE asset_id=?').all(a.id)
      .forEach(r => { cv[r.field_key] = r.value; });
    data.push([a.asset_tag,a.serial,a.model,a.category,a.status,a.location,a.manufacturer,
      a.supplier,a.purchase_date||'',a.purchase_cost||'',a.assign_to,a.prev_assigned,a.ram,
      a.processor,a.ssd,a.hdd,a.gpu,a.machine_condition,a.market_value||'',a.notes||'',
      ...fields.map(f => cv[f.field_key] || '')
    ]);
  }
  const buffer = xlsx.build([{ name: 'Assets', data }]);
  res.setHeader('Content-Disposition', `attachment; filename="ozi-assets-${Date.now()}.xlsx"`);
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.send(buffer);
});

// Export PDF (HTML → print-ready page served as text/html with print styles)
app.get('/api/export/pdf', (req, res) => {
  const rows = getAllFiltered(req.query);
  const fields = db.prepare('SELECT * FROM custom_fields ORDER BY sort_order').all();
  const now = new Date().toLocaleString();
  const esc = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

  const trs = rows.map(a => {
    const cv = {};
    db.prepare('SELECT field_key,value FROM asset_custom_values WHERE asset_id=?').all(a.id)
      .forEach(r => { cv[r.field_key] = r.value; });
    return `<tr>
      <td>${esc(a.asset_tag)}</td><td>${esc(a.model)}</td><td>${esc(a.category)}</td>
      <td>${esc(a.manufacturer)}</td><td>${esc(a.assign_to)}</td><td>${esc(a.ram)}</td>
      <td>${esc(a.gpu)}</td><td>${esc(a.machine_condition)}</td>
      <td>${a.market_value ? 'PKR '+Number(a.market_value).toLocaleString() : ''}</td>
      ${fields.map(f=>`<td>${esc(cv[f.field_key]||'')}</td>`).join('')}
    </tr>`;
  }).join('');

  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8">
  <title>OZI-G Asset Report</title>
  <style>
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:Arial,sans-serif;font-size:10px;color:#111;padding:16px}
    h1{font-size:16px;margin-bottom:2px}
    .meta{font-size:10px;color:#555;margin-bottom:12px}
    table{width:100%;border-collapse:collapse;font-size:9px}
    th{background:#185FA5;color:#fff;padding:5px 6px;text-align:left;white-space:nowrap}
    td{padding:4px 6px;border-bottom:0.5px solid #ddd;vertical-align:top}
    tr:nth-child(even) td{background:#f5f7fa}
    .footer{margin-top:12px;font-size:9px;color:#888;text-align:right}
    @media print{
      @page{margin:10mm;size:A4 landscape}
      body{padding:0}
    }
  </style>
  </head><body>
  <h1>OZI-G IT Asset Inventory Report</h1>
  <div class="meta">Generated: ${now} &nbsp;·&nbsp; Total records: ${rows.length}</div>
  <table>
    <thead><tr>
      <th>Asset Tag</th><th>Model</th><th>Category</th><th>Manufacturer</th>
      <th>Assigned To</th><th>RAM</th><th>GPU</th><th>Condition</th><th>Market Value</th>
      ${fields.map(f=>`<th>${esc(f.label)}</th>`).join('')}
    </tr></thead>
    <tbody>${trs}</tbody>
  </table>
  <div class="footer">OZI-G IT Asset Inventory &nbsp;·&nbsp; ${now}</div>
  <script>window.onload=()=>window.print()</script>
  </body></html>`;

  res.setHeader('Content-Type', 'text/html');
  res.send(html);
});

// ── Excel Import ──────────────────────────────────────────────
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (/\.(xlsx|xls|csv)$/i.test(file.originalname)) cb(null, true);
    else cb(new multer.MulterError('LIMIT_UNEXPECTED_FILE', 'Only .xlsx .xls .csv allowed'));
  }
});

const COL_MAP = {
  'asset tag':'asset_tag','assettag':'asset_tag','tag':'asset_tag',
  'serial':'serial','serial number':'serial','serialno':'serial',
  'model':'model','category':'category','type':'category','status':'status',
  'location':'location','manufacturer':'manufacturer','make':'manufacturer','mfr':'manufacturer',
  'supplier':'supplier','vendor':'supplier',
  'purchase date':'purchase_date','purchasedate':'purchase_date','date':'purchase_date',
  'purchase cost':'purchase_cost','purchasecost':'purchase_cost','cost':'purchase_cost','price':'purchase_cost',
  'assign to':'assign_to','assignto':'assign_to','assigned to':'assign_to','assignedto':'assign_to','user':'assign_to',
  'prev assigned':'prev_assigned','previously assigned':'prev_assigned','prevassigned':'prev_assigned',
  'ram':'ram','memory':'ram','processor':'processor','cpu':'processor',
  'ssd':'ssd','hdd':'hdd','hard disk':'hdd','gpu':'gpu','graphic card':'gpu','graphics':'gpu',
  'machine condition':'machine_condition','condition':'machine_condition',
  'market value':'market_value','marketvalue':'market_value','value':'market_value',
  'company':'company','notes':'notes','remarks':'notes',
};

function normalizeKey(k) { return (k||'').toString().toLowerCase().trim().replace(/\s+/g,' '); }

function parseFile(buffer, originalname) {
  if (/\.csv$/i.test(originalname||'')) {
    const text = buffer.toString('utf8');
    const lines = text.split(/\r?\n/).filter(l => l.trim());
    if (!lines.length) return [];
    const splitCSV = line => line.split(',').map(v => v.replace(/^"|"$/g,'').trim());
    const headers = splitCSV(lines[0]);
    return lines.slice(1).map(line => {
      const vals = splitCSV(line);
      const obj = {};
      headers.forEach((h,i) => { obj[h] = vals[i]||''; });
      return obj;
    });
  }
  const sheets = xlsx.parse(buffer);
  if (!sheets.length || !sheets[0].data.length) return [];
  const [headerRow, ...dataRows] = sheets[0].data;
  const headers = headerRow.map(v => v===null||v===undefined ? '' : String(v));
  return dataRows.map(vals => {
    const obj = {};
    headers.forEach((h,i) => { obj[h] = vals[i]===undefined ? '' : vals[i]; });
    return obj;
  });
}

function mapRow(raw) {
  const mapped = {};
  for (const [k,v] of Object.entries(raw)) {
    const dbField = COL_MAP[normalizeKey(k)];
    if (dbField) mapped[dbField] = v===null||v===undefined ? '' : String(v).trim();
  }
  return mapped;
}

app.post('/api/import/preview', (req, res) => {
  upload.single('file')(req, res, err => {
    if (err) return res.status(400).json({ error: err.message });
    try {
      if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
      const rows = parseFile(req.file.buffer, req.file.originalname);
      if (!rows.length) return res.status(400).json({ error: 'File empty or unreadable' });
      const mapped = rows.map(mapRow);
      const valid = mapped.filter(r => r.asset_tag);
      const skipped = mapped.length - valid.length;
      const existing = new Set(db.prepare('SELECT asset_tag FROM assets').all().map(r => r.asset_tag));
      const preview = valid.map(r => ({ ...r, _exists: existing.has(r.asset_tag) }));
      res.json({ total: rows.length, valid: valid.length, skipped, preview });
    } catch (e) { res.status(400).json({ error: e.message }); }
  });
});

app.post('/api/import/commit', express.json({ limit: '5mb' }), (req, res) => {
  const { rows, overwrite } = req.body;
  if (!Array.isArray(rows)||!rows.length) return res.status(400).json({ error: 'No rows' });
  const insert = db.prepare(`INSERT INTO assets
    (company,asset_tag,serial,model,category,status,location,manufacturer,supplier,
     purchase_date,purchase_cost,assign_to,prev_assigned,ram,processor,ssd,hdd,gpu,machine_condition,market_value,notes)
    VALUES (@company,@asset_tag,@serial,@model,@category,@status,@location,@manufacturer,@supplier,
     @purchase_date,@purchase_cost,@assign_to,@prev_assigned,@ram,@processor,@ssd,@hdd,@gpu,@machine_condition,@market_value,@notes)`);
  const update = db.prepare(`UPDATE assets SET company=@company,serial=@serial,model=@model,category=@category,
    status=@status,location=@location,manufacturer=@manufacturer,supplier=@supplier,purchase_date=@purchase_date,
    purchase_cost=@purchase_cost,assign_to=@assign_to,prev_assigned=@prev_assigned,ram=@ram,processor=@processor,
    ssd=@ssd,hdd=@hdd,gpu=@gpu,machine_condition=@machine_condition,market_value=@market_value,notes=@notes,
    updated_at=datetime('now') WHERE asset_tag=@asset_tag`);
  let inserted=0, updated=0, errors=[];
  const existing = new Set(db.prepare('SELECT asset_tag FROM assets').all().map(r => r.asset_tag));
  db.transaction(() => {
    for (const raw of rows) {
      const r = { company:raw.company||'OZI-G', asset_tag:(raw.asset_tag||'').trim(),
        serial:raw.serial||'', model:raw.model||'', category:raw.category||'Desktop',
        status:raw.status||'Ready to Deploy', location:raw.location||'',
        manufacturer:raw.manufacturer||'', supplier:raw.supplier||'',
        purchase_date:raw.purchase_date||null, purchase_cost:raw.purchase_cost?parseFloat(raw.purchase_cost)||null:null,
        assign_to:raw.assign_to||'', prev_assigned:raw.prev_assigned||'',
        ram:raw.ram||'', processor:raw.processor||'', ssd:raw.ssd||'', hdd:raw.hdd||'', gpu:raw.gpu||'',
        machine_condition:raw.machine_condition||'Good',
        market_value:raw.market_value?parseFloat(raw.market_value)||null:null, notes:raw.notes||'' };
      if (!r.asset_tag) { errors.push('Skipped row with no asset_tag'); continue; }
      try {
        if (existing.has(r.asset_tag)) { if (overwrite) { update.run(r); updated++; } }
        else { insert.run(r); inserted++; }
      } catch(e) { errors.push(`${r.asset_tag}: ${e.message}`); }
    }
  })();
  res.json({ inserted, updated, errors });
});

app.get('/api/import/template', (req, res) => {
  const headers = ['Company','Asset Tag','Serial','Model','Category','Status','Location',
    'Manufacturer','Supplier','Purchase Date','Purchase Cost','Assign To','Prev Assigned',
    'RAM','Processor','SSD','HDD','GPU','Machine Condition','Market Value','Notes'];
  const example = ['OZI-G','DSK-OZIG-XXX','ABC123','Precision T5810','Desktop','Ready to Deploy',
    'OZI Technology (Head Office)','DELL','Z.I Computers','2024-01-15','85000','John Doe','',
    '32GB','Intel Xeon E5-2660 v3','480GB','1TB','NVIDIA GTX 1060 6GB','Good','65000',''];
  const csv = [headers,example].map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\r\n')+'\r\n';
  res.setHeader('Content-Disposition','attachment; filename="ozi-inventory-template.csv"');
  res.setHeader('Content-Type','text/csv');
  res.send(csv);
});

app.listen(PORT, () => console.log(`OZI-G Inventory running on http://localhost:${PORT}`));
