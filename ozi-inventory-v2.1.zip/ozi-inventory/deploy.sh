#!/bin/bash
# =============================================================
#  OZI-G IT Asset Inventory — Ubuntu Deployment Script
#  Run as: sudo bash deploy.sh
# =============================================================
set -e

APP_NAME="ozi-inventory"
APP_DIR="/opt/ozi-inventory"
APP_USER="ozi-inventory"
PORT=3000

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║   OZI-G IT Asset Inventory Installer     ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# 1. Check root
if [ "$EUID" -ne 0 ]; then
  echo "❌  Please run as root: sudo bash deploy.sh"
  exit 1
fi

# 2. Install Node.js 20 LTS if not present
if ! command -v node &>/dev/null; then
  echo "→ Installing Node.js 20 LTS..."
  apt-get update -qq
  apt-get install -y -qq curl
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y -qq nodejs
else
  echo "✓ Node.js $(node -v) already installed"
fi

# 3. Install build tools for native modules (better-sqlite3)
echo "→ Installing build tools..."
apt-get install -y -qq build-essential python3

# 4. Create app user
if ! id "$APP_USER" &>/dev/null; then
  echo "→ Creating system user: $APP_USER"
  useradd --system --no-create-home --shell /bin/false "$APP_USER"
else
  echo "✓ User $APP_USER already exists"
fi

# 5. Copy app files
echo "→ Copying application files to $APP_DIR..."
mkdir -p "$APP_DIR"
cp -r "$(dirname "$0")/." "$APP_DIR/"
mkdir -p "$APP_DIR/data"

# 6. Install npm dependencies
echo "→ Installing npm dependencies..."
cd "$APP_DIR"
npm install --omit=dev --quiet

# 7. Set permissions
chown -R "$APP_USER:$APP_USER" "$APP_DIR"
chmod -R 750 "$APP_DIR"
chmod 770 "$APP_DIR/data"

# 8. Create systemd service
echo "→ Creating systemd service..."
cat > /etc/systemd/system/ozi-inventory.service << EOF
[Unit]
Description=OZI-G IT Asset Inventory System
After=network.target

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/node $APP_DIR/server.js
Restart=on-failure
RestartSec=5
Environment=NODE_ENV=production
Environment=PORT=$PORT

# Security hardening
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=$APP_DIR/data

[Install]
WantedBy=multi-user.target
EOF

# 9. Enable and start service
systemctl daemon-reload
systemctl enable ozi-inventory
systemctl restart ozi-inventory

# 10. Configure UFW firewall (if active)
if command -v ufw &>/dev/null && ufw status | grep -q "Status: active"; then
  echo "→ Opening port $PORT in firewall..."
  ufw allow "$PORT/tcp" comment "OZI Inventory" >/dev/null
fi

# 11. Optional: Install nginx reverse proxy
echo ""
read -p "Install Nginx reverse proxy on port 80? [y/N] " INSTALL_NGINX
if [[ "$INSTALL_NGINX" =~ ^[Yy]$ ]]; then
  apt-get install -y -qq nginx
  cat > /etc/nginx/sites-available/ozi-inventory << EOF2
server {
    listen 80;
    server_name _;

    location / {
        proxy_pass http://127.0.0.1:$PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF2
  ln -sf /etc/nginx/sites-available/ozi-inventory /etc/nginx/sites-enabled/
  rm -f /etc/nginx/sites-enabled/default
  nginx -t && systemctl restart nginx
  ufw allow 'Nginx HTTP' >/dev/null 2>&1 || true
  echo "✓ Nginx installed — app available on port 80"
fi

# 12. Done
echo ""
SERVER_IP=$(hostname -I | awk '{print $1}')
echo "╔══════════════════════════════════════════════════╗"
echo "║  ✅  OZI-G Inventory deployed successfully!      ║"
echo "║                                                  ║"
echo "║  App URL:    http://$SERVER_IP:$PORT              "
echo "║  App dir:    $APP_DIR                            "
echo "║  Data dir:   $APP_DIR/data                       "
echo "║  Database:   $APP_DIR/data/inventory.db          "
echo "║                                                  ║"
echo "║  Manage service:                                 ║"
echo "║    sudo systemctl status ozi-inventory           ║"
echo "║    sudo systemctl restart ozi-inventory          ║"
echo "║    sudo journalctl -u ozi-inventory -f           ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
