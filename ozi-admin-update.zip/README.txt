# OZI-G Inventory — Admin update

## Included
- Updated `index.html` (based on your uploaded `index(4).html`)
- Updated `server.js` with login, one-time Super Admin setup, hashed passwords, expiring server-side sessions, account management, and role enforcement
- Updated `package.json`

## Roles
- **Super Admin:** full control, including Super Admin account administration
- **Admin:** manages inventory, settings and regular user accounts; cannot administer Super Admin accounts
- **Junior:** may add records; cannot edit/delete existing records or change settings/users
- **Viewer:** read-only

## Deploy carefully
1. Take a full backup of your current project directory and `data/inventory.db`.
2. Replace the live `public/index.html` with this package's `index.html` (rename it to `index.html`).
3. Replace the live `server.js` and `package.json` with these versions.
4. Keep your existing `data/inventory.db`. Do not delete the `data` folder.
5. Run `npm install` and then restart the Node application with `npm start`.
6. Open the application. If there are no app users yet, the first-run Super Admin setup form will appear. Create a unique username and a password of at least 12 characters.
7. Sign in, then create additional users from User Management.

## Setup security
- The initial setup endpoint is one-time: it stops accepting setup after the first Super Admin is created.
- Optionally set `SETUP_KEY` in your server environment before first startup; the setup form will then require the same key.
- Do not expose the setup key or admin password in source code.
- Use HTTPS in production. Sessions expire after 8 hours and are invalidated when a user's account/role/password is changed.

## Data compatibility
The server adds separate `app_state`, `app_users`, and `app_sessions` tables to the existing SQLite database. Existing `assets`, `custom_fields`, and `asset_custom_values` tables are retained. If the new application data store is empty, it imports the existing asset rows into the larger interface's data shape. Back up the database before deploying.

## Important limitation
Your uploaded backend and large HTML file were from different application generations. This update provides the endpoints the large HTML expects and migrates the legacy `assets` table. Test with a database backup/staging copy before production cutover, especially any custom fields or asset records whose older schema differs from the large HTML's fields.
