const express = require('express');
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const ExcelJS = require('exceljs');

const app = express();
const PORT = process.env.PORT || 3000;

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

const db = new Database(path.join(DATA_DIR, 'inventory.db'));

// Init schema
db.exec(`
  CREATE TABLE IF NOT EXISTS assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company TEXT DEFAULT 'OZI-G',
    asset_tag TEXT UNIQUE NOT NULL,
    serial TEXT,
    model TEXT,
    category TEXT,
    status TEXT DEFAULT 'Ready to Deploy',
    location TEXT,
    manufacturer TEXT,
    supplier TEXT,
    purchase_date TEXT,
    purchase_cost REAL,
    assign_to TEXT,
    prev_assigned TEXT,
    ram TEXT,
    processor TEXT,
    ssd TEXT,
    hdd TEXT,
    gpu TEXT,
    machine_condition TEXT DEFAULT 'Good',
    market_value REAL,
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );
`);

// Seed data if empty
const count = db.prepare('SELECT COUNT(*) as c FROM assets').get();
if (count.c === 0) {
  const insert = db.prepare(`
    INSERT OR IGNORE INTO assets
    (company,asset_tag,serial,model,category,status,location,manufacturer,supplier,purchase_date,purchase_cost,assign_to,prev_assigned,ram,processor,ssd,hdd,gpu,machine_condition,market_value)
    VALUES (@company,@asset_tag,@serial,@model,@category,@status,@location,@manufacturer,@supplier,@purchase_date,@purchase_cost,@assign_to,@prev_assigned,@ram,@processor,@ssd,@hdd,@gpu,@machine_condition,@market_value)
  `);
  const seed = db.transaction((rows) => { for (const r of rows) insert.run(r); });
  seed([
    {company:'OZI-G',asset_tag:'DSK-OZIG-001',serial:'5JYRF2S',model:'Precision T3600',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'FREE',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'',ram:'16GB',processor:'Quad Core E5-1620 3.60GHz',ssd:'480GB',hdd:'',gpu:'NVIDIA GeForce GTX 1060 6GB',machine_condition:'Good',market_value:45000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-002',serial:'CP51CD2',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Z.I Computers',purchase_date:'2020-11-09',purchase_cost:138000,assign_to:'Aftab Ali',prev_assigned:'OZI-G',ram:'32GB',processor:'Intel Xeon E5 1650 V3 @ 3.50GHz',ssd:'480GB',hdd:'1TB',gpu:'Radeon RX 580 8GB',machine_condition:'Good',market_value:70000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-003',serial:'HC1BDH2',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Dabeer Irfan',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'',ram:'32GB',processor:'Intel Xeon E5-2660 v3 @ 2.60GHz',ssd:'240GB',hdd:'2TB',gpu:'NVIDIA GTX 1050 Ti 4GB',machine_condition:'Good',market_value:65000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-004',serial:'59R0KB2',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Z.I Computers',purchase_date:'2022-09-19',purchase_cost:77000,assign_to:'Daniyal Jawad',prev_assigned:'OZI-G',ram:'32GB',processor:'Intel Xeon E5-2660 V3 @ 2.60GHz',ssd:'480GB',hdd:'1TB',gpu:'',machine_condition:'Good',market_value:65000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-005',serial:'37Y7XK2',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Z.I Computers',purchase_date:'2022-09-19',purchase_cost:81000,assign_to:'Muhammad Faiq',prev_assigned:'OZI-G',ram:'32GB',processor:'Intel Xeon E5-2658 V3 @ 2.20GHz',ssd:'480GB',hdd:'1TB, 1TB',gpu:'AMD RX 580 Series',machine_condition:'Good',market_value:65000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-006',serial:'5VZYF2S',model:'Precision T7600',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'FREE / In IT Inventory',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'',ram:'32GB',processor:'Octa Core E5-2660 @ 2.20GHz x2',ssd:'480GB',hdd:'',gpu:'NVIDIA GeForce GTX 1060 6GB',machine_condition:'Good',market_value:90000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-007',serial:'J3TBC2S',model:'Precision T5500',category:'Desktop',status:'Faulty',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'',purchase_date:null,purchase_cost:null,assign_to:'FAULTY',prev_assigned:'',ram:'16GB',processor:'Intel Xeon E5645 Hexa Core 2.4GHz',ssd:'',hdd:'',gpu:'',machine_condition:'Poor',market_value:30000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-008',serial:'6LVCJB2',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Halta Enterprises',purchase_date:'2022-09-19',purchase_cost:82000,assign_to:'Muhammad Usama Irshad',prev_assigned:'Playcraft',ram:'32GB',processor:'Intel Xeon 2670 v3',ssd:'512GB',hdd:'500GB',gpu:'NVIDIA GTX 1060 3GB',machine_condition:'Good',market_value:60000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-010',serial:'R8PG59X',model:'Thinkstation D20',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'Lenovo',supplier:'FREE / In IT Inventory',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'AppWing',ram:'16GB',processor:'Intel Xeon X5690 / 3.33GHz (2 processors)',ssd:'256GB',hdd:'1TB',gpu:'NVIDIA GeForce GTX 1060 6GB',machine_condition:'Good',market_value:70000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-011',serial:'FLQ0ZY1',model:'Precision T3600',category:'Desktop',status:'Ready to Deploy',location:'OZI-LABS',manufacturer:'DELL',supplier:'OUT OF OFFICE',purchase_date:null,purchase_cost:null,assign_to:'OZI-LABS',prev_assigned:'',ram:'16GB',processor:'Intel Xeon E5-1660 @ 3.30GHz',ssd:'256GB',hdd:'1TB',gpu:'NVIDIA GeForce GTX 1050 Ti',machine_condition:'Good',market_value:60000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-012',serial:'8C6WJS1',model:'Precision T5500',category:'Desktop',status:'Ready to Deploy',location:'OZI-LABS',manufacturer:'DELL',supplier:'OUT OF OFFICE',purchase_date:null,purchase_cost:null,assign_to:'OZI-LABS',prev_assigned:'',ram:'32GB',processor:'Intel Xeon X5675 @ 3.07GHz',ssd:'256GB',hdd:'1TB',gpu:'NVIDIA GeForce GTX 1050 4GB TI',machine_condition:'Good',market_value:55000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-013',serial:'2UA8112514',model:'Z440',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'HP',supplier:'Game & Greeks',purchase_date:'2022-09-19',purchase_cost:128500,assign_to:'Ex-Nauman Aslam',prev_assigned:'OZI-G',ram:'32GB',processor:'Intel Xeon E5-2670 v3 @ 2.30GHz',ssd:'512GB',hdd:'2TB',gpu:'NVIDIA GeForce GTX 1060 3GB (Dual Fan)',machine_condition:'Good',market_value:70000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-014',serial:'INVALID',model:'Asus Gaming Board',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'Asus',supplier:"Gamer's Bay",purchase_date:'2022-08-03',purchase_cost:585000,assign_to:'Rendering Machine / Local VM',prev_assigned:'AppWing',ram:'64GB',processor:'Intel Core i9-11900k 11th Gen',ssd:'NVMe M.2 1TB',hdd:'2TB',gpu:'NVIDIA RTX 3060 12GB',machine_condition:'Excellent',market_value:385000},
    {company:'OZI-G',asset_tag:'DSK-OZIG-015',serial:'F7GT182',model:'Precision T5810',category:'Desktop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Salar Jahan Wallah',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'',ram:'32GB',processor:'Intel Xeon E5-2673 v3 @ 2.40GHz',ssd:'500NVMe',hdd:'1TB',gpu:'Zotac GTX 1060 3GB',machine_condition:'Good',market_value:60000},
    {company:'OZI-G',asset_tag:'LPT-OZIG-001',serial:'PF2PJ4PP',model:'82FG',category:'Laptop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'Lenovo',supplier:'Century Laptops',purchase_date:'2022-09-19',purchase_cost:151000,assign_to:'Ghulam Ahmad',prev_assigned:'OZI-G',ram:'16GB',processor:'Intel Core i7 11th Generation',ssd:'512GB',hdd:'',gpu:'NVIDIA MX 450',machine_condition:'Good',market_value:80000},
    {company:'OZI-G',asset_tag:'LPT-OZIG-002',serial:'C02W81Z0HTDF',model:'MacBook Pro 2017 15-inch',category:'Laptop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'Apple',supplier:'Laptop World',purchase_date:'2017-01-01',purchase_cost:280000,assign_to:'Haseeb Ahmed',prev_assigned:'OZI-G',ram:'16GB',processor:'Intel Core i7 @ 3.10GHz',ssd:'1TB',hdd:'',gpu:'4GB',machine_condition:'Good',market_value:185000},
    {company:'OZI-G',asset_tag:'LPT-OZIG-004',serial:'PF07MRV2',model:'80 E5',category:'Laptop',status:'Ready to Deploy',location:'OZI-LABS',manufacturer:'Lenovo',supplier:'OUT OF OFFICE',purchase_date:null,purchase_cost:null,assign_to:'OZI-LABS',prev_assigned:'',ram:'8GB',processor:'Intel Core i5',ssd:'256GB',hdd:'500GB',gpu:'AMD Radeon R5 M330',machine_condition:'Good',market_value:null},
    {company:'OZI-G',asset_tag:'LPT-OZIG-005',serial:'1RPQPH3',model:'Inspiron 3501',category:'Laptop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Century Laptops',purchase_date:'2022-01-12',purchase_cost:170000,assign_to:'Abdul Saboor',prev_assigned:'OZI-Theta',ram:'16GB',processor:'Intel Core i7-1165G7 @ 2.80GHz',ssd:'512GB',hdd:'',gpu:'NVIDIA GeForce MX330',machine_condition:'Good',market_value:110000},
    {company:'OZI-G',asset_tag:'LPT-OZIG-006',serial:'111X3G3',model:'Inspiron 3501',category:'Laptop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'DELL',supplier:'Century Laptops',purchase_date:null,purchase_cost:170000,assign_to:'Salman Sheikh',prev_assigned:'OZI-G',ram:'16GB',processor:'Intel Core i7 11th Generation',ssd:'512GB',hdd:'',gpu:'MX330 2GB',machine_condition:'Good',market_value:120000},
    {company:'OZI-G',asset_tag:'LPT-OZIG-008',serial:'5CG424DTW3',model:'ProBook 350 G1',category:'Laptop',status:'Ready to Deploy',location:'OZI Technology (Head Office)',manufacturer:'HP',supplier:'Hamza / Sheikh Sb',purchase_date:null,purchase_cost:null,assign_to:'OZI-G',prev_assigned:'',ram:'8GB',processor:'Intel Core i5-4200U @ 1.60GHz',ssd:'256GB',hdd:'500GB',gpu:'AMD HD 8600MS 2GB',machine_condition:'Good',market_value:45000},
  ]);
}

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// GET all assets with optional search/filter
app.get('/api/assets', (req, res) => {
  const { q, category, condition, page = 1, limit = 15 } = req.query;
  let sql = 'SELECT * FROM assets WHERE 1=1';
  const params = [];
  if (q) {
    sql += ' AND (asset_tag LIKE ? OR model LIKE ? OR assign_to LIKE ? OR serial LIKE ? OR manufacturer LIKE ? OR gpu LIKE ?)';
    const like = `%${q}%`;
    params.push(like, like, like, like, like, like);
  }
  if (category && category !== 'All') { sql += ' AND category = ?'; params.push(category); }
  if (condition && condition !== 'All') { sql += ' AND machine_condition = ?'; params.push(condition); }

  const total = db.prepare(`SELECT COUNT(*) as c FROM assets WHERE 1=1${sql.slice(sql.indexOf(' AND'))}`).get(...params).c;
  sql += ' ORDER BY id LIMIT ? OFFSET ?';
  params.push(Number(limit), (Number(page) - 1) * Number(limit));

  res.json({ assets: db.prepare(sql).all(...params), total, page: Number(page), limit: Number(limit) });
});

// GET single asset
app.get('/api/assets/:id', (req, res) => {
  const asset = db.prepare('SELECT * FROM assets WHERE id = ?').get(req.params.id);
  if (!asset) return res.status(404).json({ error: 'Not found' });
  res.json(asset);
});

// POST create asset
app.post('/api/assets', (req, res) => {
  const b = req.body;
  try {
    const result = db.prepare(`
      INSERT INTO assets (company,asset_tag,serial,model,category,status,location,manufacturer,supplier,
        purchase_date,purchase_cost,assign_to,prev_assigned,ram,processor,ssd,hdd,gpu,machine_condition,market_value,notes)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    `).run(b.company||'OZI-G',b.asset_tag,b.serial,b.model,b.category,b.status||'Ready to Deploy',
      b.location,b.manufacturer,b.supplier,b.purchase_date||null,b.purchase_cost||null,
      b.assign_to,b.prev_assigned,b.ram,b.processor,b.ssd,b.hdd,b.gpu,
      b.machine_condition||'Good',b.market_value||null,b.notes);
    res.json({ id: result.lastInsertRowid, message: 'Asset created' });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// PUT update asset
app.put('/api/assets/:id', (req, res) => {
  const b = req.body;
  try {
    db.prepare(`
      UPDATE assets SET company=?,asset_tag=?,serial=?,model=?,category=?,status=?,location=?,
        manufacturer=?,supplier=?,purchase_date=?,purchase_cost=?,assign_to=?,prev_assigned=?,
        ram=?,processor=?,ssd=?,hdd=?,gpu=?,machine_condition=?,market_value=?,notes=?,
        updated_at=datetime('now')
      WHERE id=?
    `).run(b.company||'OZI-G',b.asset_tag,b.serial,b.model,b.category,b.status,
      b.location,b.manufacturer,b.supplier,b.purchase_date||null,b.purchase_cost||null,
      b.assign_to,b.prev_assigned,b.ram,b.processor,b.ssd,b.hdd,b.gpu,
      b.machine_condition,b.market_value||null,b.notes,req.params.id);
    res.json({ message: 'Asset updated' });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// DELETE asset
app.delete('/api/assets/:id', (req, res) => {
  db.prepare('DELETE FROM assets WHERE id = ?').run(req.params.id);
  res.json({ message: 'Asset deleted' });
});

// GET stats
app.get('/api/stats', (req, res) => {
  const total = db.prepare('SELECT COUNT(*) as c FROM assets').get().c;
  const byCategory = db.prepare('SELECT category, COUNT(*) as c FROM assets GROUP BY category').all();
  const byCondition = db.prepare('SELECT machine_condition, COUNT(*) as c FROM assets GROUP BY machine_condition').all();
  const marketValue = db.prepare('SELECT SUM(market_value) as total FROM assets').get().total || 0;
  const purchaseCost = db.prepare('SELECT SUM(purchase_cost) as total FROM assets').get().total || 0;
  res.json({ total, byCategory, byCondition, marketValue, purchaseCost });
});

// ── Excel Upload ──────────────────────────────────────────────
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB max
  fileFilter: (req, file, cb) => {
    if (/\.(xlsx|xls|csv)$/i.test(file.originalname)) {
      cb(null, true);
    } else {
      cb(new multer.MulterError('LIMIT_UNEXPECTED_FILE', 'Only .xlsx, .xls or .csv files are allowed'));
    }
  }
});

// Column name aliases — maps whatever header the Excel uses → our DB field
const COL_MAP = {
  'asset tag': 'asset_tag', 'assettag': 'asset_tag', 'tag': 'asset_tag',
  'serial': 'serial', 'serial number': 'serial', 'serialno': 'serial',
  'model': 'model',
  'category': 'category', 'type': 'category',
  'status': 'status',
  'location': 'location',
  'manufacturer': 'manufacturer', 'make': 'manufacturer', 'mfr': 'manufacturer',
  'supplier': 'supplier', 'vendor': 'supplier',
  'purchase date': 'purchase_date', 'purchasedate': 'purchase_date', 'date': 'purchase_date',
  'purchase cost': 'purchase_cost', 'purchasecost': 'purchase_cost', 'cost': 'purchase_cost', 'price': 'purchase_cost',
  'assign to': 'assign_to', 'assignto': 'assign_to', 'assigned to': 'assign_to', 'assignedto': 'assign_to', 'user': 'assign_to',
  'prev assigned': 'prev_assigned', 'previously assigned': 'prev_assigned', 'prevassigned': 'prev_assigned',
  'ram': 'ram', 'memory': 'ram',
  'processor': 'processor', 'cpu': 'processor',
  'ssd': 'ssd',
  'hdd': 'hdd', 'hard disk': 'hdd',
  'gpu': 'gpu', 'graphic card': 'gpu', 'graphics': 'gpu',
  'machine condition': 'machine_condition', 'condition': 'machine_condition',
  'market value': 'market_value', 'marketvalue': 'market_value', 'value': 'market_value',
  'company': 'company',
  'notes': 'notes', 'remarks': 'notes',
};

function normalizeKey(k) {
  return (k || '').toString().toLowerCase().trim().replace(/\s+/g, ' ');
}

async function parseExcel(buffer, originalname) {
  const isCSV = /\.csv$/i.test(originalname || '');

  if (isCSV) {
    const wb = new ExcelJS.Workbook();
    const stream = require('stream');
    const readable = new stream.PassThrough();
    readable.end(buffer);
    await wb.csv.read(readable);
    const ws = wb.worksheets[0];
    if (!ws) return [];
    const rows = [];
    let headers = [];
    ws.eachRow((row, rowNum) => {
      const vals = row.values.slice(1);
      if (rowNum === 1) {
        headers = vals.map(v => (v === null || v === undefined ? '' : String(v)));
      } else {
        const obj = {};
        headers.forEach((h, i) => { obj[h] = vals[i] === undefined ? '' : vals[i]; });
        rows.push(obj);
      }
    });
    return rows;
  }

  // xlsx / xls
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(buffer);
  const ws = wb.worksheets[0];
  if (!ws) return [];
  const rows = [];
  let headers = [];
  ws.eachRow((row, rowNum) => {
    const vals = row.values.slice(1);
    if (rowNum === 1) {
      headers = vals.map(v => (v === null || v === undefined ? '' : String(v)));
    } else {
      const obj = {};
      headers.forEach((h, i) => { obj[h] = vals[i] === undefined ? '' : vals[i]; });
      rows.push(obj);
    }
  });
  return rows;
}

function mapRow(raw) {
  const mapped = {};
  for (const [k, v] of Object.entries(raw)) {
    const dbField = COL_MAP[normalizeKey(k)];
    if (dbField) mapped[dbField] = v === null || v === undefined ? '' : String(v).trim();
  }
  return mapped;
}

// POST /api/import/preview — parse & return rows without saving
app.post('/api/import/preview', (req, res) => {
  upload.single('file')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message });
    handlePreview(req, res);
  });
});

async function handlePreview(req, res) {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const rows = await parseExcel(req.file.buffer, req.file.originalname);
    if (!rows.length) return res.status(400).json({ error: 'File is empty or unreadable' });

    const mapped = rows.map(mapRow);
    const valid = mapped.filter(r => r.asset_tag);
    const skipped = mapped.length - valid.length;

    // Check which asset_tags already exist
    const existing = new Set(
      db.prepare('SELECT asset_tag FROM assets').all().map(r => r.asset_tag)
    );
    const preview = valid.map(r => ({
      ...r,
      _exists: existing.has(r.asset_tag),
    }));

    res.json({ total: rows.length, valid: valid.length, skipped, preview });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
}

// POST /api/import/commit — save rows to DB
app.post('/api/import/commit', express.json({ limit: '5mb' }), (req, res) => {
  const { rows, overwrite } = req.body;
  if (!Array.isArray(rows) || !rows.length) return res.status(400).json({ error: 'No rows provided' });

  const insert = db.prepare(`
    INSERT INTO assets
      (company,asset_tag,serial,model,category,status,location,manufacturer,supplier,
       purchase_date,purchase_cost,assign_to,prev_assigned,ram,processor,ssd,hdd,gpu,
       machine_condition,market_value,notes)
    VALUES
      (@company,@asset_tag,@serial,@model,@category,@status,@location,@manufacturer,@supplier,
       @purchase_date,@purchase_cost,@assign_to,@prev_assigned,@ram,@processor,@ssd,@hdd,@gpu,
       @machine_condition,@market_value,@notes)
  `);
  const update = db.prepare(`
    UPDATE assets SET
      company=@company,serial=@serial,model=@model,category=@category,status=@status,
      location=@location,manufacturer=@manufacturer,supplier=@supplier,purchase_date=@purchase_date,
      purchase_cost=@purchase_cost,assign_to=@assign_to,prev_assigned=@prev_assigned,ram=@ram,
      processor=@processor,ssd=@ssd,hdd=@hdd,gpu=@gpu,machine_condition=@machine_condition,
      market_value=@market_value,notes=@notes,updated_at=datetime('now')
    WHERE asset_tag=@asset_tag
  `);

  let inserted = 0, updated = 0, errors = [];
  const existing = new Set(db.prepare('SELECT asset_tag FROM assets').all().map(r => r.asset_tag));

  const run = db.transaction(() => {
    for (const raw of rows) {
      const r = {
        company: raw.company || 'OZI-G',
        asset_tag: (raw.asset_tag || '').trim(),
        serial: raw.serial || '',
        model: raw.model || '',
        category: raw.category || 'Desktop',
        status: raw.status || 'Ready to Deploy',
        location: raw.location || '',
        manufacturer: raw.manufacturer || '',
        supplier: raw.supplier || '',
        purchase_date: raw.purchase_date || null,
        purchase_cost: raw.purchase_cost ? parseFloat(raw.purchase_cost) || null : null,
        assign_to: raw.assign_to || '',
        prev_assigned: raw.prev_assigned || '',
        ram: raw.ram || '',
        processor: raw.processor || '',
        ssd: raw.ssd || '',
        hdd: raw.hdd || '',
        gpu: raw.gpu || '',
        machine_condition: raw.machine_condition || 'Good',
        market_value: raw.market_value ? parseFloat(raw.market_value) || null : null,
        notes: raw.notes || '',
      };
      if (!r.asset_tag) { errors.push('Skipped row with no asset_tag'); continue; }
      try {
        if (existing.has(r.asset_tag)) {
          if (overwrite) { update.run(r); updated++; }
        } else {
          insert.run(r); inserted++;
        }
      } catch (e) {
        errors.push(`${r.asset_tag}: ${e.message}`);
      }
    }
  });

  run();
  res.json({ inserted, updated, errors });
});

// GET /api/import/template — download Excel template
app.get('/api/import/template', async (req, res) => {
  const headers = ['Company','Asset Tag','Serial','Model','Category','Status','Location',
    'Manufacturer','Supplier','Purchase Date','Purchase Cost','Assign To','Prev Assigned',
    'RAM','Processor','SSD','HDD','GPU','Machine Condition','Market Value','Notes'];
  const example = ['OZI-G','DSK-OZIG-XXX','ABC123','Precision T5810','Desktop','Ready to Deploy',
    'OZI Technology (Head Office)','DELL','Z.I Computers','2024-01-15',85000,'John Doe','',
    '32GB','Intel Xeon E5-2660 v3','480GB','1TB','NVIDIA GTX 1060 6GB','Good',65000,''];

  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Assets');

  const headerRow = ws.addRow(headers);
  headerRow.eachCell(cell => {
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF185FA5' } };
    cell.alignment = { vertical: 'middle' };
  });
  ws.addRow(example);
  ws.columns = headers.map(() => ({ width: 20 }));

  res.setHeader('Content-Disposition', 'attachment; filename="ozi-inventory-template.xlsx"');
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  await wb.xlsx.write(res);
  res.end();
});

app.listen(PORT, () => console.log(`OZI-G Inventory running on http://localhost:${PORT}`));
