'use strict';
/**
 * Reset (or recreate) the admin login.
 *
 *   cd /opt/ozi-inventory
 *   sudo -u ozi-inventory node reset-admin.js            # prints a random temporary password
 *   sudo -u ozi-inventory node reset-admin.js "MyTemp#2026"
 *
 * The temporary password must be changed at next login, and every
 * existing admin session is signed out.
 * Run it as the service user (not plain root) so the database file keeps its owner.
 */
const path = require('path');
const crypto = require('crypto');
const Database = require('better-sqlite3');
const createAuth = require('./auth');

const dbFile = path.join(__dirname, 'data', 'inventory.db');
const db = new Database(dbFile);
const auth = createAuth(db);

const pw = process.argv[2] || crypto.randomBytes(9).toString('base64url');
if (pw.length < 8) {
  console.error('Password must be at least 8 characters.');
  process.exit(1);
}

const result = auth.resetPassword('admin', pw);
console.log(`\nAdmin user ${result === 'created' ? 'created' : 'password reset'}.`);
console.log('  Username : admin');
console.log(`  Password : ${pw}`);
console.log('You will be asked to choose a new password at the next login.\n');
