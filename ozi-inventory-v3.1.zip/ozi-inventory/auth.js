'use strict';
/**
 * Authentication for OZI-G Inventory.
 *  - Passwords: scrypt (built into Node), random salt per user
 *  - Sessions : random 256-bit token in an HttpOnly cookie; only its SHA-256 is stored in the DB
 *  - Lockout  : 5 failed logins from one IP => locked for 15 minutes
 * No third-party packages required.
 */
const crypto = require('crypto');

const COOKIE_NAME = 'ozi_sid';
const SESSION_MS = 12 * 60 * 60 * 1000;      // 12 hours
const DEFAULT_ADMIN_PASSWORD = 'Admin@1234';
const MIN_PASSWORD_LEN = 8;
const MAX_PASSWORD_LEN = 200;
const MAX_FAILS = 5;
const LOCK_MS = 15 * 60 * 1000;

// Reachable without a session (everything else is gated)
const PUBLIC_PATHS = new Set(['/login.html', '/favicon.ico', '/api/login', '/api/logout']);
// Allowed while the admin still has to choose a new password
const CHANGE_PW_ALLOWED = new Set(['/api/change-password', '/api/me', '/api/logout']);

const sha256 = s => crypto.createHash('sha256').update(s).digest('hex');

function hashPassword(password, saltHex) {
  const salt = saltHex ? Buffer.from(saltHex, 'hex') : crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64);
  return { salt: salt.toString('hex'), hash: hash.toString('hex') };
}

function verifyPassword(password, saltHex, hashHex) {
  const { hash } = hashPassword(password, saltHex);
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(hashHex, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function parseCookies(header) {
  const out = {};
  String(header || '').split(';').forEach(part => {
    const i = part.indexOf('=');
    if (i < 1) return;
    try { out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); } catch (e) { /* ignore bad cookie */ }
  });
  return out;
}

function isHttps(req) {
  return !!req.secure || (req.headers && req.headers['x-forwarded-proto'] === 'https');
}

function setSessionCookie(req, res, value, maxAgeSeconds) {
  let c = `${COOKIE_NAME}=${value}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAgeSeconds}`;
  if (isHttps(req)) c += '; Secure';
  res.setHeader('Set-Cookie', c);
}

function createAuth(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      username      TEXT UNIQUE NOT NULL COLLATE NOCASE,
      password_hash TEXT NOT NULL,
      salt          TEXT NOT NULL,
      role          TEXT NOT NULL DEFAULT 'admin',
      must_change   INTEGER NOT NULL DEFAULT 0,
      created_at    TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      user_id    INTEGER NOT NULL,
      expires_at INTEGER NOT NULL
    );
  `);

  const failures = new Map();                 // ip -> { count, until }
  const DUMMY = hashPassword('timing-equaliser'); // so unknown usernames cost the same as wrong passwords

  // ── users ────────────────────────────────────────────────────
  function ensureAdmin() {
    const n = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
    if (n > 0) return null;
    const envPw = process.env.OZI_ADMIN_PASSWORD;
    const { salt, hash } = hashPassword(envPw || DEFAULT_ADMIN_PASSWORD);
    db.prepare("INSERT INTO users (username, password_hash, salt, role, must_change) VALUES ('admin', ?, ?, 'admin', ?)")
      .run(hash, salt, envPw ? 0 : 1);
    return { username: 'admin', usedDefault: !envPw };
  }

  function resetPassword(username, newPassword) {
    const { salt, hash } = hashPassword(newPassword);
    const user = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
    if (!user) {
      db.prepare("INSERT INTO users (username, password_hash, salt, role, must_change) VALUES (?, ?, ?, 'admin', 1)")
        .run(username, hash, salt);
      return 'created';
    }
    db.prepare('UPDATE users SET password_hash = ?, salt = ?, must_change = 1 WHERE id = ?').run(hash, salt, user.id);
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(user.id);
    return 'reset';
  }

  // ── sessions ─────────────────────────────────────────────────
  function createSession(userId) {
    const token = crypto.randomBytes(32).toString('hex');
    db.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)')
      .run(sha256(token), userId, Date.now() + SESSION_MS);
    return token;
  }

  function getSession(req) {
    const token = parseCookies(req.headers && req.headers.cookie)[COOKIE_NAME];
    if (!token) return null;
    const row = db.prepare(`
      SELECT u.id, u.username, u.role, u.must_change, s.expires_at, s.token_hash
      FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.token_hash = ?`).get(sha256(token));
    if (!row) return null;
    if (row.expires_at < Date.now()) {
      db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(row.token_hash);
      return null;
    }
    return row;
  }

  function purgeExpired() {
    db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now());
  }

  // ── middleware: nothing but the login page is reachable without a session ──
  function requireAuth(req, res, next) {
    if (PUBLIC_PATHS.has(req.path)) return next();

    const isApi = req.path.startsWith('/api/');
    const sess = getSession(req);

    if (!sess) {
      if (isApi) return res.status(401).json({ error: 'Not authenticated' });
      return res.redirect('/login.html');
    }

    if (sess.must_change) {
      if (isApi && !CHANGE_PW_ALLOWED.has(req.path)) {
        return res.status(403).json({ error: 'Password change required', must_change: true });
      }
      if (!isApi) return res.redirect('/login.html');
    }

    req.user = sess;
    next();
  }

  // ── route handlers ───────────────────────────────────────────
  function login(req, res) {
    const ip = req.ip || (req.socket && req.socket.remoteAddress) || 'unknown';
    const f = failures.get(ip);
    if (f && f.until > Date.now()) {
      const mins = Math.ceil((f.until - Date.now()) / 60000);
      return res.status(429).json({ error: `Too many failed attempts. Try again in ${mins} minute${mins === 1 ? '' : 's'}.` });
    }

    const { username, password } = req.body || {};
    if (typeof username !== 'string' || typeof password !== 'string' || !username.trim() || !password || password.length > MAX_PASSWORD_LEN) {
      return res.status(400).json({ error: 'Username and password are required.' });
    }

    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username.trim());
    let ok = false;
    if (user) ok = verifyPassword(password, user.salt, user.password_hash);
    else verifyPassword(password, DUMMY.salt, DUMMY.hash);

    if (!ok) {
      const cur = f && !(f.until && f.until <= Date.now()) ? f : { count: 0, until: 0 };
      cur.count += 1;
      if (cur.count >= MAX_FAILS) { cur.until = Date.now() + LOCK_MS; cur.count = 0; }
      failures.set(ip, cur);
      if (failures.size > 5000) {
        for (const [k, v] of failures) if (v.until && v.until <= Date.now()) failures.delete(k);
      }
      return res.status(401).json({ error: 'Invalid username or password.' });
    }

    failures.delete(ip);
    purgeExpired();
    const token = createSession(user.id);
    setSessionCookie(req, res, token, SESSION_MS / 1000);
    res.json({ ok: true, username: user.username, must_change: !!user.must_change });
  }

  function logout(req, res) {
    const token = parseCookies(req.headers && req.headers.cookie)[COOKIE_NAME];
    if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
    setSessionCookie(req, res, '', 0);
    res.json({ ok: true });
  }

  function me(req, res) {
    res.json({ username: req.user.username, role: req.user.role, must_change: !!req.user.must_change });
  }

  // NOTE: wrong current password returns 400 (not 401) so the browser stays on the page.
  function changePassword(req, res) {
    const { current_password, new_password } = req.body || {};
    if (typeof current_password !== 'string' || typeof new_password !== 'string') {
      return res.status(400).json({ error: 'Current and new password are required.' });
    }
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
    if (!user || !verifyPassword(current_password, user.salt, user.password_hash)) {
      return res.status(400).json({ error: 'Current password is incorrect.' });
    }
    if (new_password.length < MIN_PASSWORD_LEN) {
      return res.status(400).json({ error: `New password must be at least ${MIN_PASSWORD_LEN} characters.` });
    }
    if (new_password.length > MAX_PASSWORD_LEN) {
      return res.status(400).json({ error: 'New password is too long.' });
    }
    if (new_password === current_password) {
      return res.status(400).json({ error: 'New password must be different from the current one.' });
    }
    if (new_password === DEFAULT_ADMIN_PASSWORD) {
      return res.status(400).json({ error: 'Please choose a password other than the default.' });
    }

    const { salt, hash } = hashPassword(new_password);
    db.prepare('UPDATE users SET password_hash = ?, salt = ?, must_change = 0 WHERE id = ?').run(hash, salt, user.id);

    // Sign out every other device that was using this account
    const keep = sha256(parseCookies(req.headers && req.headers.cookie)[COOKIE_NAME] || '');
    db.prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash <> ?').run(user.id, keep);

    res.json({ ok: true });
  }

  return { ensureAdmin, resetPassword, requireAuth, login, logout, me, changePassword, purgeExpired };
}

module.exports = createAuth;
module.exports.hashPassword = hashPassword;
module.exports.verifyPassword = verifyPassword;
module.exports.DEFAULT_ADMIN_PASSWORD = DEFAULT_ADMIN_PASSWORD;
