# OZI-G IT Asset Inventory System

A full-stack web app for managing OZI-G IT assets. Built with Node.js, Express, and SQLite.

---

## Quick Deploy on Ubuntu

### Option A — Automated (recommended)

```bash
# 1. Transfer files to your Ubuntu server
scp -r ozi-inventory/ user@your-server-ip:/home/user/

# 2. SSH into your server
ssh user@your-server-ip

# 3. Run the deploy script
cd ozi-inventory
sudo bash deploy.sh
```

That's it. The script will:
- Install Node.js 20 LTS
- Install build tools
- Copy the app to `/opt/ozi-inventory`
- Create a dedicated system user
- Register and start a systemd service
- Optionally set up Nginx on port 80

---

### Option B — Manual setup

```bash
# Update system
sudo apt-get update && sudo apt-get upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs build-essential

# Install dependencies
cd ozi-inventory
npm install

# Start the server
node server.js
# App runs at http://localhost:3000
```

---

### Option C — Run with PM2 (production process manager)

```bash
# Install PM2 globally
sudo npm install -g pm2

# Start app
cd /opt/ozi-inventory
pm2 start server.js --name ozi-inventory

# Save process list and enable on boot
pm2 save
pm2 startup
```

---

## Service Management

```bash
# Check status
sudo systemctl status ozi-inventory

# Restart
sudo systemctl restart ozi-inventory

# View live logs
sudo journalctl -u ozi-inventory -f

# Stop
sudo systemctl stop ozi-inventory
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/assets | List assets (supports ?q=, ?category=, ?condition=, ?page=, ?limit=) |
| GET | /api/assets/:id | Get single asset |
| POST | /api/assets | Create asset |
| PUT | /api/assets/:id | Update asset |
| DELETE | /api/assets/:id | Delete asset |
| GET | /api/stats | Dashboard statistics |

---

## File Structure

```
ozi-inventory/
├── server.js          # Express + SQLite backend
├── package.json
├── deploy.sh          # Ubuntu deployment script
├── data/
│   └── inventory.db   # SQLite database (auto-created)
└── public/
    ├── index.html     # Frontend UI
    ├── style.css      # Styles
    └── app.js         # Frontend logic
```

---

## Backup the database

```bash
# Simple backup
cp /opt/ozi-inventory/data/inventory.db ~/inventory-backup-$(date +%Y%m%d).db

# Cron job backup (daily at 2am)
(crontab -l 2>/dev/null; echo "0 2 * * * cp /opt/ozi-inventory/data/inventory.db ~/backups/inventory-\$(date +\%Y\%m\%d).db") | crontab -
```


---

## Login & Security

The app now requires a sign-in. Nothing (pages or data) is reachable without it.

**First login:** `admin` / `Admin@1234` — you are forced to choose a new password straight away.
(Optionally set `OZI_ADMIN_PASSWORD` before the *first* start to seed a different initial password; no forced change in that case.)

**Change password any time:** sidebar → *Change password*.

**Forgot the password?**
```bash
cd /opt/ozi-inventory
sudo -u ozi-inventory node reset-admin.js        # prints a random temporary password
```
Run it as `ozi-inventory` (not plain root) so the database keeps the right owner.

**How it behaves**
- Sessions last 12 hours; logging out or changing the password signs out other devices.
- 5 wrong passwords from one address locks sign-in for 15 minutes (`sudo systemctl restart ozi-inventory` clears it).
- Passwords are stored hashed (scrypt), never in plain text.
- Over plain `http://` on your LAN the password is not encrypted in transit. If untrusted people share the network, put Nginx with HTTPS in front.
